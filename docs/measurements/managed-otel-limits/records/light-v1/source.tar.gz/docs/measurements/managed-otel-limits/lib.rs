// Compile the real Reader, its real tests and unchanged codec by source path.
#[path = "../../../crates/init/src/metrics.rs"]
pub mod metrics;

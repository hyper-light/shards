pub(super) struct Metadata { pub(super) value: u32 }
impl Metadata { pub(super) fn new() -> Self { Self { value: 1 } } }

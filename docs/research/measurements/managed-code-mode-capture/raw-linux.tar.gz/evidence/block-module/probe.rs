#![allow(dead_code)]
fn consumer() {
    #[path = "leaf.rs"]
    mod capture;
    use capture::Metadata;
    let _ = Metadata::new().value;
}

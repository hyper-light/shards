#!/usr/bin/env python3
"""Approved actor-free codec fixture: exact source hydration, then one native test."""
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import tarfile
import time
import urllib.request

BASE = Path('/tmp/shards-managed-audit-corpus-v1')
CORE_BYTES = 7556700
CORE_SHA = 'ffb24d54155e243f19693a5a35a813aa5f5e0cfe2cc19216d171a231756e9ce4'
MANIFEST_SHA = '35cb167dfb863f3cda7267b5c0dabfe8aa19f6e8babc47d23a8874712f85491e'
LOCK_SHA = 'f4dd0fa9a0563349fe5b3fd6ce31119b6d227a446560716f252ee993570ee3da'
CONFIG_SHA = 'c7e64e8e9d4392421dfc684f738e78a4239aec865171e128495a21e6f74d0ace'
FMT_SHA = 'dd70402f4c840303db9ec2afce7480a63198f972d1ae7b4cb07327511b4da4fa'
TEST = 'broker::corpus::broker_emit_audit_fixture_corpus'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def relative(name):
    path = Path(name)
    if path.is_absolute() or '..' in path.parts:
        raise SystemExit('unsafe package path')
    return path


def record(path, value):
    with path.open('x') as out:
        json.dump(value, out, indent=2)
        out.write('\n')


def hydrate(scope):
    parts = sorted((scope / 'parts').iterdir())
    data = b''.join(path.read_bytes() for path in parts)
    if len(data) != CORE_BYTES or sha(data) != CORE_SHA:
        raise SystemExit('core package length/hash differs')
    with (scope / 'core.tar.gz').open('xb') as out:
        out.write(data)
    source = scope / 'source'
    source.mkdir(mode=0o700)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        names = set()
        for entry in archive:
            name = relative(entry.name)
            if entry.name in names or not entry.isfile():
                raise SystemExit('duplicate/nonregular core member')
            names.add(entry.name)
            path = source / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(entry) as inp, path.open('xb') as out:
                out.write(inp.read())
            path.chmod(entry.mode)
    raw = (source / 'corpus-package-manifest.json').read_bytes()
    if sha(raw) != MANIFEST_SHA:
        raise SystemExit('package manifest hash differs')
    manifest = json.loads(raw)
    missing = []
    downloads = []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for name, version in manifest['vendor_versions'].items():
        prefix = 'vendor/' + name + '/'
        expected = {row['path'][len(prefix):]: row for row in manifest['files'] if row['path'].startswith(prefix)}
        url = 'https://static.crates.io/crates/' + name + '/' + name + '-' + version + '.crate'
        package = scope / (name + '-' + version + '.crate')
        with opener.open(url, timeout=30) as inp, package.open('xb') as out:
            while True:
                chunk = inp.read(io.DEFAULT_BUFFER_SIZE)
                if not chunk:
                    break
                if out.tell() + len(chunk) > 4 * 1024 ** 3:
                    raise SystemExit('public source exceeds task storage envelope')
                out.write(chunk)
        downloads.append(dict(url=url, bytes=package.stat().st_size, sha256=sha(package.read_bytes())))
        seen = set()
        with tarfile.open(package, 'r:gz') as archive:
            for entry in archive:
                path = relative(entry.name)
                first, *rest = path.parts
                if first != name + '-' + version:
                    raise SystemExit('unexpected public package root')
                rel = Path(*rest).as_posix()
                row = expected.get(rel)
                if row is None:
                    continue
                if rel in seen or not entry.isfile():
                    raise SystemExit('duplicate/nonregular expected vendor member')
                seen.add(rel)
                data = archive.extractfile(entry).read(row['bytes'] + 1)
                if len(data) != row['bytes'] or sha(data) != row['sha256']:
                    missing.append(row['path'])
                    continue
                target = source / row['path']
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as out:
                    out.write(data)
                target.chmod(row['mode'])
        missing.extend(expected[rel]['path'] for rel in expected.keys() - seen)
    record(scope / 'hydration.json', dict(downloads=downloads, local_exact_overlays_needed=sorted(missing),
                                         source_revision=manifest['revision'], manifest_sha256=MANIFEST_SHA))
    print(json.dumps(dict(overlays_needed=sorted(missing), downloads=downloads)), flush=True)


def invoke(scope, name, command, env, timeout, cwd):
    record(scope / (name + '.command.json'), dict(command=command, cwd=str(cwd), timeout_s=timeout,
                                                env={k: env[k] for k in env if k != 'PATH'}))
    began = time.monotonic()
    with (scope / (name + '.stdout')).open('xb') as out, (scope / (name + '.stderr')).open('xb') as err:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=out, stderr=err, start_new_session=True)
        try:
            result = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            result = process.wait(timeout=15)
            record(scope / (name + '.timeout.json'), dict(deadline_s=timeout, termination=result))
            raise SystemExit(name + ' exceeded original deadline')
    record(scope / (name + '.result.json'), dict(exit_code=result, elapsed_s=time.monotonic() - began))
    print(name, result, flush=True)
    if result:
        raise SystemExit(name + ' failed; original stdout/stderr retained')


def run(scope):
    source = scope / 'source'
    raw = (source / 'corpus-package-manifest.json').read_bytes()
    if sha(raw) != MANIFEST_SHA:
        raise SystemExit('manifest changed')
    manifest = json.loads(raw)
    for row in manifest['files']:
        path = source / relative(row['path'])
        if path.is_symlink() or not path.is_file():
            raise SystemExit('missing/nonregular source ' + row['path'])
        data = path.read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise SystemExit('source hash differs ' + row['path'])
    for name, expected in [('Cargo.lock', LOCK_SHA), ('.cargo/config.toml', CONFIG_SHA), ('rustfmt.toml', FMT_SHA)]:
        if sha((source / name).read_bytes()) != expected:
            raise SystemExit('product lock/config differs')
    cargo_home = scope / 'cargo-home'
    cargo_home.mkdir(mode=0o700)
    target = scope / 'target'
    target.mkdir(mode=0o700)
    temporary = scope / 'tmp'
    temporary.mkdir(mode=0o700)
    env = dict(PATH=os.environ['PATH'], CARGO_HOME=str(cargo_home), CARGO_TARGET_DIR=str(target),
               CARGO_BUILD_JOBS='2', TMPDIR=str(temporary), LANG='C',
               RUSTUP_HOME='/home/adalundhe/.rustup')
    record(scope / 'source-verified.json', dict(revision=manifest['revision'], manifest_sha256=MANIFEST_SHA,
                                               files=len(manifest['files']), lock_sha256=LOCK_SHA,
                                               config_sha256=CONFIG_SHA, rustfmt_sha256=FMT_SHA))
    invoke(scope, 'policy', ['scripts/check-development-policy'], env, 30, source)
    invoke(scope, 'metadata', ['cargo', 'metadata', '--locked', '--no-deps', '--format-version=1'], env, 180, source)
    metadata = json.loads((scope / 'metadata.stdout').read_text())
    if Path(metadata['workspace_root']).resolve() != source.resolve() or Path(metadata['target_directory']).resolve() != target.resolve():
        raise SystemExit('Cargo workspace/target escaped')
    selected = next(p for p in metadata['packages'] if p['name'] == 'shards-server')
    actual = [t for t in selected['targets'] if t['name'] == 'shards-server' and 'bin' in t['kind']]
    if len(actual) != 1 or Path(actual[0]['src_path']).resolve() != (source / 'crates/server/src/main.rs').resolve():
        raise SystemExit('real Cargo target root differs')
    for package in metadata['packages']:
        for item in package['targets']:
            path = Path(item['src_path']).resolve()
            if not path.is_relative_to(source.resolve()) or not path.is_file():
                raise SystemExit('actual workspace target absent/escaped ' + str(path))
    record(scope / 'target-verified.json', dict(package=selected['id'], target=actual[0], target_directory=str(target)))
    record(scope / 'toolchain.json', dict(rustc=subprocess.check_output(['rustc','-vV'], env=env, text=True),
                                         cargo=subprocess.check_output(['cargo','--version'], env=env, text=True),
                                         uname=platform.uname()._asdict()))
    invoke(scope, 'build', ['cargo','test','-p','shards-server','--locked','--profile','test-release','-j2','--no-run','--message-format=json'], env, 180, source)
    binaries = []
    for line in (scope / 'build.stdout').read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get('reason') == 'compiler-artifact' and row.get('target',{}).get('name') == 'shards-server' and row.get('profile',{}).get('test') and row.get('executable'):
            binaries.append(Path(row['executable']))
    if len(binaries) != 1 or not binaries[0].resolve().is_relative_to(target.resolve()):
        raise SystemExit('actual test artifact absent/escaped')
    binary = binaries[0]
    record(scope / 'binary.json', dict(path=str(binary), bytes=binary.stat().st_size, sha256=sha(binary.read_bytes())))
    env['SHARDS_AUDIT_CORPUS_DIR'] = str(scope / 'corpus')
    invoke(scope, 'emit', [str(binary),'--exact',TEST,'--nocapture','--test-threads=1'], env, 30, source)
    text = (scope / 'emit.stdout').read_text()
    if '1 passed; 0 failed; 0 ignored' not in text or not (scope / 'corpus/inputs.json').is_file():
        raise SystemExit('actual generator did not execute once')
    rows = []
    for path in sorted((scope / 'corpus').iterdir()):
        if path.is_symlink() or not path.is_file():
            raise SystemExit('nonregular corpus payload')
        data = path.read_bytes()
        rows.append(dict(path=path.name,bytes=len(data),sha256=sha(data)))
    record(scope / 'corpus-manifest.json', dict(source_revision=manifest['revision'], binary_sha256=sha(binary.read_bytes()),files=rows))
    print(json.dumps(dict(corpus_files=len(rows),inputs=json.loads((scope / 'corpus/inputs.json').read_text()))), flush=True)


if __name__ == '__main__':
    scope = BASE / sys.argv[2]
    if scope.is_symlink() or not scope.resolve().is_relative_to(BASE.resolve()):
        raise SystemExit('scope escaped')
    if sys.argv[1] == 'hydrate':
        hydrate(scope)
    elif sys.argv[1] == 'run':
        run(scope)
    else:
        raise SystemExit('unknown phase')

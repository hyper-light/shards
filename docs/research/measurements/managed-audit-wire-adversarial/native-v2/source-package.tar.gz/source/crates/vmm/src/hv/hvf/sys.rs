//! Thin safe wrappers over Hypervisor.framework (arm64).
//!
//! HVF allows one VM per process and binds each vCPU to the thread that created it
//! (docs/research/hvf-arm64-kvm-ground-truth.md §1.1). [`Vcpu`] is therefore `!Send`;
//! the only cross-thread vCPU operation, forcing an exit, goes through [`VcpuKicker`].

use std::ffi::c_void;
use std::fmt;
use std::marker::PhantomData;
use std::sync::atomic::{AtomicBool, Ordering};

use super::ffi;

/// A failed Hypervisor.framework call.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Error {
    pub op: &'static str,
    pub code: i32,
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let name = match self.code as u32 {
            0xfae9_4001 => "HV_ERROR",
            0xfae9_4002 => "HV_BUSY",
            0xfae9_4003 => "HV_BAD_ARGUMENT",
            0xfae9_4004 => "HV_ILLEGAL_GUEST_STATE",
            0xfae9_4005 => "HV_NO_RESOURCES",
            0xfae9_4006 => "HV_NO_DEVICE",
            0xfae9_4007 => "HV_DENIED (is the binary signed with com.apple.security.hypervisor?)",
            0xfae9_4008 => "HV_EXISTS",
            0xfae9_400f => "HV_UNSUPPORTED",
            _ => "unknown",
        };
        write!(f, "{} failed: {name} ({:#x})", self.op, self.code as u32)
    }
}

impl std::error::Error for Error {}

pub type Result<T> = std::result::Result<T, Error>;

fn check(op: &'static str, code: ffi::hv_return_t) -> Result<()> {
    if code == ffi::HV_SUCCESS {
        Ok(())
    } else {
        Err(Error { op, code })
    }
}

/// Stage-2 permissions for a guest-physical mapping.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Perms(u64);

impl Perms {
    pub const RWX: Perms = Perms(ffi::HV_MEMORY_READ | ffi::HV_MEMORY_WRITE | ffi::HV_MEMORY_EXEC);
    pub const RX: Perms = Perms(ffi::HV_MEMORY_READ | ffi::HV_MEMORY_EXEC);
    /// Data alone: a GPU's blobs (D144), a run's swap (D159).
    pub const RW: Perms = Perms(ffi::HV_MEMORY_READ | ffi::HV_MEMORY_WRITE);
    /// Data read alone: a swap window's zeros (D159).
    pub const R: Perms = Perms(ffi::HV_MEMORY_READ);
    /// No access: every touch exits to the VMM.
    pub const NONE: Perms = Perms(0);

    /// Whether the guest may write it.
    pub fn writes(self) -> bool {
        self.0 & ffi::HV_MEMORY_WRITE != 0
    }

    /// The same, the guest's writes taken away.
    pub fn read_only(self) -> Perms {
        Perms(self.0 & !ffi::HV_MEMORY_WRITE)
    }
}

#[derive(Debug, Clone, Copy)]
pub struct VmConfig {
    /// Guest physical address width; `None` keeps the framework default (36 bits).
    pub ipa_bits: Option<u32>,
    /// Whether the vCPUs have EL2 (macOS 15, on a Mac that can give it).
    pub el2: bool,
}

/// Whether this Mac gives a guest EL2 (`hv_vm_config_get_el2_supported`): nested
/// virtualization, from the M3 on macOS 15.
pub fn el2_supported() -> bool {
    let mut supported = false;
    // SAFETY: a pointer to a local bool, written on success.
    let res = unsafe { ffi::hv_vm_config_get_el2_supported(&mut supported) };
    res == ffi::HV_SUCCESS && supported
}

static VM_EXISTS: AtomicBool = AtomicBool::new(false);

/// The process's virtual machine. Destroying it requires every [`Vcpu`] to be gone.
#[derive(Debug)]
pub struct Vm(());

impl Vm {
    pub fn new(config: VmConfig) -> Result<Vm> {
        if VM_EXISTS.swap(true, Ordering::AcqRel) {
            return Err(Error {
                op: "hv_vm_create (second VM in process)",
                code: ffi::HV_EXISTS,
            });
        }
        // SAFETY: config objects are created, configured and released on this thread.
        let res = unsafe {
            let cfg = ffi::hv_vm_config_create();
            // The 16 KiB IPA granule: first touch costs 4x less per byte than 4 KiB (PM M5,
            // D6). It is the only granule before macOS 26, which added the setter.
            let mut res = match ffi::set_ipa_granule_fn() {
                Some(set) => check("hv_vm_config_set_ipa_granule", set(cfg, ffi::HV_IPA_GRANULE_16KB)),
                None => Ok(()),
            };
            if let (Ok(()), Some(bits)) = (res, config.ipa_bits) {
                res = check(
                    "hv_vm_config_set_ipa_size",
                    ffi::hv_vm_config_set_ipa_size(cfg, bits),
                );
            }
            if res.is_ok() && config.el2 {
                res = check(
                    "hv_vm_config_set_el2_enabled",
                    ffi::hv_vm_config_set_el2_enabled(cfg, true),
                );
            }
            if res.is_ok() {
                res = check("hv_vm_create", ffi::hv_vm_create(cfg));
            }
            ffi::os_release(cfg);
            res
        };
        match res {
            Ok(()) => Ok(Vm(())),
            Err(e) => {
                VM_EXISTS.store(false, Ordering::Release);
                Err(e)
            }
        }
    }

    /// Maps `size` bytes of host memory at `host` to guest-physical `gpa`.
    ///
    /// # Safety
    /// `host..host+size` must be a single host VM region (e.g. from `mmap`) that stays
    /// mapped until it is unmapped here or the VM is destroyed.
    pub unsafe fn map(&self, host: *mut u8, gpa: u64, size: usize, perms: Perms) -> Result<()> {
        // SAFETY: forwarded caller contract.
        unsafe { map(host, gpa, size, perms) }
    }

    /// Unmaps `size` bytes at guest-physical `gpa`.
    pub fn unmap(&self, gpa: u64, size: usize) -> Result<()> {
        unmap(gpa, size)
    }

    /// Creates the in-kernel GICv3. Must happen before any vCPU is created.
    pub fn create_gic(&self, layout: &GicLayout) -> Result<Gic> {
        // SAFETY: the config object is created, used and released on this thread.
        unsafe {
            let cfg = ffi::hv_gic_config_create();
            let mut res = check(
                "hv_gic_config_set_distributor_base",
                ffi::hv_gic_config_set_distributor_base(cfg, layout.dist_base),
            );
            if res.is_ok() {
                res = check(
                    "hv_gic_config_set_redistributor_base",
                    ffi::hv_gic_config_set_redistributor_base(cfg, layout.redist_base),
                );
            }
            if let (Ok(()), Some(msi)) = (res, layout.msi) {
                res = check(
                    "hv_gic_config_set_msi_region_base",
                    ffi::hv_gic_config_set_msi_region_base(cfg, msi.base),
                );
                if res.is_ok() {
                    res = check(
                        "hv_gic_config_set_msi_interrupt_range",
                        ffi::hv_gic_config_set_msi_interrupt_range(cfg, msi.first_intid, msi.count),
                    );
                }
            }
            if res.is_ok() {
                res = check("hv_gic_create", ffi::hv_gic_create(cfg));
            }
            ffi::os_release(cfg);
            res.map(|()| Gic(()))
        }
    }
}

/// Maps `size` bytes of host memory at `host` to guest-physical `gpa` in the process's VM,
/// which must exist: [`Vm::map`]'s, for a holder of a handle the VM made.
///
/// # Safety
/// As for [`Vm::map`].
pub unsafe fn map(host: *mut u8, gpa: u64, size: usize, perms: Perms) -> Result<()> {
    // SAFETY: forwarded caller contract.
    check("hv_vm_map", unsafe {
        ffi::hv_vm_map(host as *mut c_void, gpa, size, perms.0)
    })
}

/// Unmaps `size` bytes at guest-physical `gpa` in the process's VM, which must exist.
pub fn unmap(gpa: u64, size: usize) -> Result<()> {
    // SAFETY: no host memory is passed.
    check("hv_vm_unmap", unsafe { ffi::hv_vm_unmap(gpa, size) })
}

impl Drop for Vm {
    fn drop(&mut self) {
        // SAFETY: all vCPUs borrow nothing from `Vm`, but HVF requires they be destroyed
        // first; the VMM joins every vCPU thread before dropping the VM.
        let code = unsafe { ffi::hv_vm_destroy() };
        if code != ffi::HV_SUCCESS {
            crate::warn!(
                "{}",
                Error {
                    op: "hv_vm_destroy",
                    code
                }
            );
        }
        VM_EXISTS.store(false, Ordering::Release);
    }
}

/// Sets the guest's access to `len` mapped bytes at `gpa`, in the process's VM. Callable
/// from any thread, while vCPUs run.
pub fn protect(gpa: u64, len: u64, perms: Perms) -> Result<()> {
    let size = usize::try_from(len).map_err(|_| Error {
        op: "hv_vm_protect",
        code: ffi::HV_BAD_ARGUMENT,
    })?;
    // SAFETY: no host memory is passed; HVF checks that the range is mapped.
    check("hv_vm_protect", unsafe { ffi::hv_vm_protect(gpa, size, perms.0) })
}

/// Whether this Mac can run Hypervisor.framework VMs: `sysctl kern.hv_support`, the check
/// Apple documents. It reads 0 inside VMs that lack nested virtualization.
pub fn supported() -> bool {
    let mut value: libc::c_int = 0;
    let mut len = size_of::<libc::c_int>();
    // SAFETY: sysctlbyname writes at most `len` bytes into `value`.
    let rc = unsafe {
        libc::sysctlbyname(
            c"kern.hv_support".as_ptr(),
            (&raw mut value).cast(),
            &mut len,
            std::ptr::null_mut(),
            0,
        )
    };
    rc == 0 && value == 1
}

/// Maximum number of vCPUs a VM can have on this host.
pub fn max_vcpus() -> Result<u32> {
    let mut n = 0;
    // SAFETY: writes one u32.
    check("hv_vm_get_max_vcpu_count", unsafe {
        ffi::hv_vm_get_max_vcpu_count(&mut n)
    })?;
    Ok(n)
}

/// Largest supported guest physical address width.
pub fn max_ipa_bits() -> Result<u32> {
    let mut n = 0;
    // SAFETY: writes one u32.
    check("hv_vm_config_get_max_ipa_size", unsafe {
        ffi::hv_vm_config_get_max_ipa_size(&mut n)
    })?;
    Ok(n)
}

/// Distributor register by GICD offset; callable from any thread (hv_gic.h). Tests read
/// the GIC's state through it.
#[cfg(test)]
pub fn dist_reg(offset: u16) -> Result<u64> {
    let mut v = 0;
    // SAFETY: writes one u64.
    check("hv_gic_get_distributor_reg", unsafe {
        ffi::hv_gic_get_distributor_reg(offset, &mut v)
    })?;
    Ok(v)
}

#[cfg(test)]
pub fn set_dist_reg(offset: u16, value: u64) -> Result<()> {
    // SAFETY: no memory is passed.
    check("hv_gic_set_distributor_reg", unsafe {
        ffi::hv_gic_set_distributor_reg(offset, value)
    })
}

/// The GIC device's state, as Hypervisor.framework serializes it: "the complete serialized
/// state of the device, except for the GIC cpu registers", stable and versioned
/// (hv_gic_state.h). It holds what the distributor and redistributor registers do not, such
/// as interrupts on their way to a vCPU. The VM must be stopped.
pub fn gic_state() -> Result<Vec<u8>> {
    // SAFETY: returns a retained object, released below, or NULL.
    let state = unsafe { ffi::hv_gic_state_create() };
    if state.is_null() {
        return Err(Error {
            op: "hv_gic_state_create",
            code: ffi::HV_ERROR,
        });
    }
    let data = (|| {
        let mut size = 0usize;
        // SAFETY: a live state object; writes one usize.
        check("hv_gic_state_get_size", unsafe {
            ffi::hv_gic_state_get_size(state, &mut size)
        })?;
        let mut data = Vec::new();
        data.try_reserve_exact(size).map_err(|_| Error {
            op: "hv_gic_state_get_data",
            code: ffi::HV_NO_RESOURCES,
        })?;
        data.resize(size, 0u8);
        // SAFETY: a live state object, and a buffer of the size it asked for.
        check("hv_gic_state_get_data", unsafe {
            ffi::hv_gic_state_get_data(state, data.as_mut_ptr().cast())
        })?;
        Ok(data)
    })();
    // SAFETY: the object hv_gic_state_create returned, released once.
    unsafe { ffi::os_release(state) };
    data
}

/// Restores [`gic_state`]'s data into this VM's GIC: after the GIC and every vCPU exist,
/// before any runs (hv_gic.h).
pub fn set_gic_state(data: &[u8]) -> Result<()> {
    // SAFETY: a buffer of `data.len()` bytes, only read.
    check("hv_gic_set_state", unsafe {
        ffi::hv_gic_set_state(data.as_ptr().cast(), data.len())
    })
}

/// The host counter guest virtual counters are offsets from (24 MHz on Apple silicon).
pub fn host_counter() -> u64 {
    // SAFETY: no arguments; reads the system counter.
    unsafe { ffi::mach_absolute_time() }
}

/// Host-imposed GIC geometry (runtime queries; they are not published constants).
#[derive(Debug, Clone, Copy)]
pub struct GicParams {
    pub dist_size: u64,
    pub dist_align: u64,
    /// One redistributor (RD_base + SGI_base frames).
    pub redist_size: u64,
    pub redist_align: u64,
    pub msi_size: u64,
    pub msi_align: u64,
    pub spi_base: u32,
    pub spi_count: u32,
}

pub fn gic_params() -> Result<GicParams> {
    let (mut ds, mut da, mut rs, mut ra, mut ms, mut ma) = (0usize, 0usize, 0usize, 0usize, 0usize, 0usize);
    let (mut sb, mut sc) = (0u32, 0u32);
    // SAFETY: each call writes one scalar.
    unsafe {
        check(
            "hv_gic_get_distributor_size",
            ffi::hv_gic_get_distributor_size(&mut ds),
        )?;
        check(
            "hv_gic_get_distributor_base_alignment",
            ffi::hv_gic_get_distributor_base_alignment(&mut da),
        )?;
        check(
            "hv_gic_get_redistributor_size",
            ffi::hv_gic_get_redistributor_size(&mut rs),
        )?;
        check(
            "hv_gic_get_redistributor_base_alignment",
            ffi::hv_gic_get_redistributor_base_alignment(&mut ra),
        )?;
        check(
            "hv_gic_get_msi_region_size",
            ffi::hv_gic_get_msi_region_size(&mut ms),
        )?;
        check(
            "hv_gic_get_msi_region_base_alignment",
            ffi::hv_gic_get_msi_region_base_alignment(&mut ma),
        )?;
        check(
            "hv_gic_get_spi_interrupt_range",
            ffi::hv_gic_get_spi_interrupt_range(&mut sb, &mut sc),
        )?;
    }
    Ok(GicParams {
        dist_size: ds as u64,
        dist_align: da as u64,
        redist_size: rs as u64,
        redist_align: ra as u64,
        msi_size: ms as u64,
        msi_align: ma as u64,
        spi_base: sb,
        spi_count: sc,
    })
}

#[derive(Debug, Clone, Copy)]
pub struct MsiFrame {
    pub base: u64,
    pub first_intid: u32,
    pub count: u32,
}

/// Where the GIC's parts are: its distributor and redistributors, and its GICv2m frame
/// (the framework's GIC has no ITS: `its` is refused).
#[derive(Debug, Clone, Copy)]
pub struct GicLayout {
    pub dist_base: u64,
    pub redist_base: u64,
    pub msi: Option<MsiFrame>,
    pub its: Option<u64>,
}

/// Handle to the in-kernel GIC. Interrupt injection is legal from any thread
/// (no owning-thread rule on `hv_gic_set_spi`/`hv_gic_send_msi`).
#[derive(Debug, Clone)]
pub struct Gic(());

impl Gic {
    /// Drives an SPI line. For edge-configured INTIDs `true` produces one edge.
    pub fn set_spi(&self, intid: u32, level: bool) -> Result<()> {
        // SAFETY: no memory is passed; HVF validates the INTID.
        check("hv_gic_set_spi", unsafe { ffi::hv_gic_set_spi(intid, level) })
    }

    /// Delivers an MSI written to `doorbell` (the frame's GICM_SET_SPI_NSR address).
    pub fn send_msi(&self, doorbell: u64, intid: u32) -> Result<()> {
        // SAFETY: no memory is passed; HVF validates address and INTID.
        check("hv_gic_send_msi", unsafe {
            ffi::hv_gic_send_msi(doorbell, intid)
        })
    }
}

/// General-purpose and special registers (`hv_reg_t`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Reg(u32);

impl Reg {
    pub const PC: Reg = Reg(ffi::HV_REG_PC);
    pub const FPCR: Reg = Reg(ffi::HV_REG_FPCR);
    pub const FPSR: Reg = Reg(ffi::HV_REG_FPSR);
    pub const CPSR: Reg = Reg(ffi::HV_REG_CPSR);

    /// `Xn` for n in 0..=30. `None` for 31, which in MMIO and system-register syndromes
    /// names XZR (reads as zero, writes discarded) and must never alias `hv_reg_t` 31 (PC).
    pub const fn x(n: u8) -> Option<Reg> {
        if n <= 30 {
            Some(Reg(ffi::HV_REG_X0 + n as u32))
        } else {
            None
        }
    }
}

/// Why `hv_vcpu_run` returned.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Exit {
    /// Forced by [`VcpuKicker::kick`].
    Canceled,
    /// Synchronous exception to EL2; `syndrome` is ESR_EL2, `ipa` the faulting IPA.
    Exception {
        syndrome: u64,
        va: u64,
        ipa: u64,
    },
    /// Only without an in-kernel GIC.
    VtimerActivated,
    Unknown(u32),
}

/// A vCPU bound to the current thread.
#[derive(Debug)]
pub struct Vcpu {
    id: ffi::hv_vcpu_t,
    exit: *const ffi::hv_vcpu_exit_t,
    _thread_bound: PhantomData<*const ()>,
}

impl Vcpu {
    /// Creates a vCPU owned by the calling thread. Redistributor frames are assigned
    /// in creation order, so callers create vCPUs strictly by index.
    pub fn new() -> Result<Vcpu> {
        let mut id = 0;
        let mut exit = std::ptr::null();
        // SAFETY: out-parameters are valid; NULL config selects defaults.
        check("hv_vcpu_create", unsafe {
            ffi::hv_vcpu_create(&mut id, &mut exit, std::ptr::null_mut())
        })?;
        Ok(Vcpu {
            id,
            exit,
            _thread_bound: PhantomData,
        })
    }

    pub fn kicker(&self) -> VcpuKicker {
        VcpuKicker(self.id)
    }

    pub fn run(&mut self) -> Result<Exit> {
        // SAFETY: owning thread (enforced by !Send); `exit` is valid for the vCPU's life
        // and only written by hv_vcpu_run on this thread.
        unsafe {
            check("hv_vcpu_run", ffi::hv_vcpu_run(self.id))?;
            let e = &*self.exit;
            Ok(match e.reason {
                ffi::HV_EXIT_REASON_CANCELED => Exit::Canceled,
                ffi::HV_EXIT_REASON_EXCEPTION => Exit::Exception {
                    syndrome: e.exception.syndrome,
                    va: e.exception.virtual_address,
                    ipa: e.exception.physical_address,
                },
                ffi::HV_EXIT_REASON_VTIMER_ACTIVATED => Exit::VtimerActivated,
                other => Exit::Unknown(other),
            })
        }
    }

    pub fn reg(&self, reg: Reg) -> Result<u64> {
        let mut v = 0;
        // SAFETY: owning thread; writes one u64.
        check("hv_vcpu_get_reg", unsafe {
            ffi::hv_vcpu_get_reg(self.id, reg.0, &mut v)
        })?;
        Ok(v)
    }

    pub fn set_reg(&mut self, reg: Reg, value: u64) -> Result<()> {
        // SAFETY: owning thread.
        check("hv_vcpu_set_reg", unsafe {
            ffi::hv_vcpu_set_reg(self.id, reg.0, value)
        })
    }

    /// Reads general-purpose register `n` as an instruction would: 31 is XZR (zero).
    pub fn x(&self, n: u8) -> Result<u64> {
        Reg::x(n).map_or(Ok(0), |r| self.reg(r))
    }

    /// Writes general-purpose register `n` as an instruction would: writes to 31 (XZR)
    /// are discarded.
    pub fn set_x(&mut self, n: u8, value: u64) -> Result<()> {
        Reg::x(n).map_or(Ok(()), |r| self.set_reg(r, value))
    }

    pub fn sys_reg(&self, reg: u16) -> Result<u64> {
        let mut v = 0;
        // SAFETY: owning thread; writes one u64.
        check("hv_vcpu_get_sys_reg", unsafe {
            ffi::hv_vcpu_get_sys_reg(self.id, reg, &mut v)
        })?;
        Ok(v)
    }

    pub fn set_sys_reg(&mut self, reg: u16, value: u64) -> Result<()> {
        // SAFETY: owning thread.
        check("hv_vcpu_set_sys_reg", unsafe {
            ffi::hv_vcpu_set_sys_reg(self.id, reg, value)
        })
    }

    /// SIMD/FP register Qn as a little-endian 128-bit value.
    pub fn simd(&self, n: u32) -> Result<u128> {
        let mut v = [0u8; 16];
        // SAFETY: owning thread; writes 16 bytes into `v`.
        check("hv_vcpu_get_simd_fp_reg", unsafe {
            ffi::hv_vcpu_get_simd_fp_reg(self.id, n, v.as_mut_ptr())
        })?;
        Ok(u128::from_le_bytes(v))
    }

    pub fn set_simd(&mut self, n: u32, value: u128) -> Result<()> {
        let v = value.to_le_bytes();
        // SAFETY: owning thread; the shim reads 16 bytes from `v`.
        check("hv_vcpu_set_simd_fp_reg", unsafe {
            ffi::shards_hv_vcpu_set_simd_fp_reg(self.id, n, v.as_ptr())
        })
    }

    /// `CNTVCT_EL0 = host_counter() - offset` for this vCPU.
    pub fn vtimer_offset(&self) -> Result<u64> {
        let mut v = 0;
        // SAFETY: owning thread; writes one u64.
        check("hv_vcpu_get_vtimer_offset", unsafe {
            ffi::hv_vcpu_get_vtimer_offset(self.id, &mut v)
        })?;
        Ok(v)
    }

    pub fn set_vtimer_offset(&mut self, offset: u64) -> Result<()> {
        // SAFETY: owning thread.
        check("hv_vcpu_set_vtimer_offset", unsafe {
            ffi::hv_vcpu_set_vtimer_offset(self.id, offset)
        })
    }

    /// GIC CPU interface register by encoding. Owning thread (hv_gic.h).
    pub fn icc_reg(&self, reg: u16) -> Result<u64> {
        let mut v = 0;
        // SAFETY: owning thread; writes one u64.
        check("hv_gic_get_icc_reg", unsafe {
            ffi::hv_gic_get_icc_reg(self.id, reg, &mut v)
        })?;
        Ok(v)
    }

    pub fn set_icc_reg(&mut self, reg: u16, value: u64) -> Result<()> {
        // SAFETY: owning thread.
        check("hv_gic_set_icc_reg", unsafe {
            ffi::hv_gic_set_icc_reg(self.id, reg, value)
        })
    }

    /// Guest-physical base of this vCPU's GIC redistributor (MPIDR must be set first).
    pub fn redistributor_base(&self) -> Result<u64> {
        let mut v = 0;
        // SAFETY: writes one u64.
        check("hv_gic_get_redistributor_base", unsafe {
            ffi::hv_gic_get_redistributor_base(self.id, &mut v)
        })?;
        Ok(v)
    }
}

impl Drop for Vcpu {
    fn drop(&mut self) {
        // SAFETY: owning thread (the value never left it).
        let code = unsafe { ffi::hv_vcpu_destroy(self.id) };
        if code != ffi::HV_SUCCESS {
            crate::warn!(
                "{}",
                Error {
                    op: "hv_vcpu_destroy",
                    code
                }
            );
        }
    }
}

/// Forces a vCPU out of `hv_vcpu_run` from any thread. If the vCPU is not running, its
/// next `run` returns [`Exit::Canceled`] immediately.
#[derive(Debug, Clone, Copy)]
pub struct VcpuKicker(ffi::hv_vcpu_t);

impl VcpuKicker {
    pub fn kick(&self) -> Result<()> {
        // SAFETY: hv_vcpus_exit is the documented cross-thread call; reads one id.
        check("hv_vcpus_exit", unsafe { ffi::hv_vcpus_exit(&self.0, 1) })
    }
}

//! The KVM backend's arm64 VM and vCPUs, with the interface the arm64 machine
//! (vm/aarch64.rs) has of Hypervisor.framework's: guest memory at stage 2, an in-kernel
//! GICv3 (KVM_DEV_TYPE_ARM_VGIC_V3, Documentation/virt/kvm/devices/arm-vgic-v3.rst), and
//! PSCI, which here is KVM's own (KVM_ARM_VCPU_PSCI_0_2, api.rst 4.82): a secondary vCPU
//! starts powered off, CPU_ON and CPU_OFF are the kernel's, and SYSTEM_OFF and
//! SYSTEM_RESET come back as system events. A trapped device access completes in the
//! kernel, which takes a read's data from the run's exit as the vCPU enters again.

mod gic;
mod prefetch;
mod state;

pub use state::VcpuState;

use std::os::fd::RawFd;
use std::sync::{Arc, Mutex, OnceLock};

use super::{Error, Kicker, Result, Slots, Thread, call, install_kick_handler, kvm, sys};
use crate::arch::aarch64::{Entry, layout, sysreg};
use crate::hv::{Exit, Io, Touch};
use crate::sync::lock;

/// Working sets' pages: the host's, as on x86_64.
pub const PAGE: u64 = 4 << 10;

/// What KVM must offer on arm64 besides what every architecture needs: its registers one
/// by one, in-kernel devices (the GICv3), and PSCI 0.2 or later.
pub(super) const REQUIRED: &[(u64, &str)] = &[
    (sys::CAP_ONE_REG, "KVM_CAP_ONE_REG"),
    (sys::CAP_DEVICE_CTRL, "KVM_CAP_DEVICE_CTRL"),
    (sys::CAP_ARM_PSCI_0_2, "KVM_CAP_ARM_PSCI_0_2"),
];

/// The most vCPUs a machine has: as many redistributors as the guest's memory map has room
/// for, contiguous from `GIC_REDIST`.
pub(super) const VCPU_LIMIT: u32 =
    ((layout::GIC_REDIST_MAX_END - layout::GIC_REDIST) / sys::VGIC_V3_REDIST_SIZE) as u32;

/// Nothing for the process to ask of Linux first.
pub(super) fn prepare() {}

/// The GIC's interrupts: 32 private to each vCPU, then the SPIs the machine uses
/// (arch::aarch64::layout), in KVM's steps of 32 (arm-vgic-v3.rst,
/// KVM_DEV_ARM_VGIC_GRP_NR_IRQS).
const NR_IRQS: u32 = (32 + layout::SPIS).next_multiple_of(32);

/// Whether a PCI bus's MSIs go to an ITS (D154): KVM's GICv3 has one (KVM_DEV_TYPE_ARM_VGIC_ITS),
/// which translates each MSI by the ID of the device that wrote it, so that its MSIs are
/// isolated from each other's, as Linux takes an ITS's (irq-gic-v3-its.c,
/// IRQ_DOMAIN_FLAG_ISOLATED_MSI) and a guest's VFIO needs (vfio_iommu_type1.c).
pub const ITS: bool = true;

/// The maintenance interrupt of a guest with EL2: PPI 9, INTID 25, as its devicetree says
/// (arch::aarch64::boot) and as Hypervisor.framework's.
const MAINTENANCE_INTID: u32 = 25;

/// MPIDR_EL1's affinity fields: Aff3 (39:32), Aff2, Aff1 and Aff0 (23:0).
const MPIDR_AFFINITY: u64 = 0xff_00ff_ffff;

/// ID registers that define the guest's CPU, as Hypervisor.framework's backend keeps them.
const ID_REGS: &[u16] = &[
    0xc000, 0xc020, 0xc021, 0xc028, 0xc029, 0xc030, 0xc031, 0xc038, 0xc039, 0xc03a,
];

/// The physical address width a VM may have here: KVM_CAP_ARM_VM_IPA_SIZE's, or 40 bits
/// where KVM sizes no VM's, as every VM then has (api.rst 4.2, KVM_CREATE_VM).
pub fn max_ipa_bits() -> Result<u32> {
    let bits = kvm()
        .map_err(Error::Guest)?
        .check_extension(sys::CAP_ARM_VM_IPA_SIZE)
        .map_err(call("KVM_CHECK_EXTENSION"))?;
    Ok(if bits > 0 { bits.unsigned_abs() } else { 40 })
}

/// Whether this host's KVM gives a guest EL2: a CPU with FEAT_NV2, its kernel booted with
/// `kvm-arm.mode=nested` (arch/arm64/kernel/cpufeature.c, has_nested_virt_support).
pub fn el2_supported() -> bool {
    kvm().is_ok_and(|k| k.check_extension(sys::CAP_ARM_EL2).is_ok_and(|n| n > 0))
}

/// Why a guest is given no EL2 here.
pub const NO_EL2: &str = "this host's KVM gives a guest no EL2: virtualization of a guest's own needs a CPU with FEAT_NV2, its kernel booted with kvm-arm.mode=nested";

/// KVM's GICv3 geometry: a distributor of one 64 KiB frame, and two for each vCPU's
/// redistributor, each placed on a 64 KiB boundary (arm-vgic-v3.rst); its SPIs, INTID 32
/// on, as many as the machine asks ([`NR_IRQS`]); and a 64 KiB place for a GICv2m frame,
/// which its machines leave empty, their MSIs going to the ITS ([`ITS`]).
#[derive(Debug, Clone, Copy)]
pub struct GicParams {
    pub dist_size: u64,
    pub dist_align: u64,
    pub redist_size: u64,
    pub redist_align: u64,
    pub msi_size: u64,
    pub msi_align: u64,
    pub spi_base: u32,
    pub spi_count: u32,
}

pub fn gic_params() -> Result<GicParams> {
    Ok(GicParams {
        dist_size: sys::VGIC_V3_DIST_SIZE,
        dist_align: 64 << 10,
        redist_size: sys::VGIC_V3_REDIST_SIZE,
        redist_align: 64 << 10,
        msi_size: 64 << 10,
        msi_align: 64 << 10,
        spi_base: 32,
        spi_count: NR_IRQS - 32,
    })
}

/// A GICv2m frame: the VMM's, at `base`, its SPIs `count` from INTID `first_intid`.
#[derive(Debug, Clone, Copy)]
pub struct MsiFrame {
    pub base: u64,
    pub first_intid: u32,
    pub count: u32,
}

/// Where the GIC's parts are: its distributor and redistributors, and its ITS (KVM's
/// machines have no GICv2m frame: `msi` is refused).
#[derive(Debug, Clone, Copy)]
pub struct GicLayout {
    pub dist_base: u64,
    pub redist_base: u64,
    pub msi: Option<MsiFrame>,
    pub its: Option<u64>,
}

/// Drives the GIC's SPIs, and the MSIs its ITS translates, from any thread.
#[derive(Debug, Clone)]
pub struct Gic(Arc<GicState>);

#[derive(Debug)]
struct GicState {
    fd: Arc<sys::VmFd>,
    /// The MSIs routed to GSIs of their own for irqfds to raise ([`Gic::route_msi`]).
    routes: Mutex<Vec<MsiRoute>>,
}

/// An MSI on a GSI of its own: its address and data, and the ID of the device that writes
/// it, which the ITS translates by.
#[derive(Debug, Clone, Copy)]
struct MsiRoute {
    gsi: u32,
    address: u64,
    data: u32,
    devid: u32,
}

impl Gic {
    /// Drives SPI `intid`'s line. For an edge-configured INTID `true` makes it pending
    /// once and `false` does nothing, as KVM injects (vgic.c, kvm_vgic_inject_irq).
    pub fn set_spi(&self, intid: u32, level: bool) -> Result<()> {
        let irq = (sys::IRQ_TYPE_SPI << sys::IRQ_TYPE_SHIFT) | (intid & sys::IRQ_NUM_MASK);
        self.0.fd.irq_line(irq, level).map_err(call("KVM_IRQ_LINE"))
    }

    /// Delivers the MSI of `address` and `data` that device `devid` wrote to the ITS,
    /// which translates it by that ID (api.rst 4.70, KVM_SIGNAL_MSI with
    /// KVM_MSI_VALID_DEVID): as a function the VMM emulates sends one.
    pub fn its_msi(&self, address: u64, data: u32, devid: u32) -> Result<()> {
        self.0
            .fd
            .signal_msi(address, data, Some(devid))
            .map_err(call("KVM_SIGNAL_MSI"))
    }

    /// Raises SPI `intid` each time `event` is written, in the kernel (KVM_IRQFD): its GSI
    /// is the SPI's number, as KVM routes every SPI by default (vgic-irqfd.c,
    /// kvm_vgic_setup_default_irq_routing). With `resample`, a level-triggered line, which
    /// KVM lowers as the guest ends the interrupt, writing `resample`.
    pub fn irqfd(&self, event: RawFd, intid: u32, resample: Option<RawFd>) -> Result<()> {
        let gsi = intid
            .checked_sub(32)
            .ok_or_else(|| Error::Guest(format!("INTID {intid}: not an SPI")))?;
        self.0.fd.irqfd(event, gsi, resample).map_err(call("KVM_IRQFD"))
    }

    /// Takes `event` from SPI `intid` again.
    pub fn irqfd_remove(&self, event: RawFd, intid: u32) -> Result<()> {
        let gsi = intid
            .checked_sub(32)
            .ok_or_else(|| Error::Guest(format!("INTID {intid}: not an SPI")))?;
        self.0.fd.irqfd_remove(event, gsi).map_err(call("KVM_IRQFD"))
    }

    /// A GSI past the SPIs' that sends the MSI of `address` and `data` from device `devid`
    /// to the ITS, which `event` then raises (KVM_IRQFD); the routing table set whole, as
    /// KVM_SET_GSI_ROUTING replaces it (api.rst 4.52): KVM's defaults, each SPI on the GSI
    /// of its number (vgic-irqfd.c, kvm_vgic_setup_default_irq_routing), and every MSI
    /// routed, each with its device's ID (KVM_MSI_VALID_DEVID).
    pub fn route_msi(&self, event: RawFd, address: u64, data: u32, devid: u32) -> Result<u32> {
        let mut routes = crate::sync::lock(&self.0.routes);
        let gsi = (NR_IRQS - 32..)
            .find(|gsi| routes.iter().all(|r| r.gsi != *gsi))
            .ok_or_else(|| Error::Guest("no GSI left for an MSI".into()))?;
        routes.push(MsiRoute {
            gsi,
            address,
            data,
            devid,
        });
        if let Err(e) = self.commit(&routes) {
            routes.pop();
            return Err(e);
        }
        if let Err(e) = self.0.fd.irqfd(event, gsi, None).map_err(call("KVM_IRQFD")) {
            routes.pop();
            let _ = self.commit(&routes);
            return Err(e);
        }
        Ok(gsi)
    }

    /// Takes `event` from the MSI route of `gsi`, and the route from the table.
    pub fn unroute_msi(&self, event: RawFd, gsi: u32) -> Result<()> {
        let mut routes = crate::sync::lock(&self.0.routes);
        self.0.fd.irqfd_remove(event, gsi).map_err(call("KVM_IRQFD"))?;
        routes.retain(|r| r.gsi != gsi);
        self.commit(&routes)
    }

    fn commit(&self, routes: &[MsiRoute]) -> Result<()> {
        let mut entries: Vec<sys::kvm_irq_routing_entry> = (0..NR_IRQS - 32)
            .map(|gsi| {
                let mut u = [0u32; 8];
                // struct kvm_irq_routing_irqchip: the irqchip, 0, and the pin, the SPI.
                u[1] = gsi;
                sys::kvm_irq_routing_entry {
                    gsi,
                    kind: sys::IRQ_ROUTING_IRQCHIP,
                    u,
                    ..Default::default()
                }
            })
            .collect();
        for r in routes {
            let mut u = [0u32; 8];
            // struct kvm_irq_routing_msi: address_lo, address_hi, data, devid.
            (u[0], u[1], u[2], u[3]) = (r.address as u32, (r.address >> 32) as u32, r.data, r.devid);
            entries.push(sys::kvm_irq_routing_entry {
                gsi: r.gsi,
                kind: sys::IRQ_ROUTING_MSI,
                flags: sys::MSI_VALID_DEVID,
                u,
                ..Default::default()
            });
        }
        self.0
            .fd
            .set_gsi_routing(&entries)
            .map_err(call("KVM_SET_GSI_ROUTING"))
    }
}

#[derive(Debug, Clone)]
pub struct VmConfig {
    /// Guest physical address width.
    pub ipa_bits: u32,
    /// MPIDR of each vCPU, by index.
    pub mpidrs: Vec<u64>,
    /// Whether the vCPUs have EL2, entered there: the guest's kernel may be a hypervisor
    /// (nested virtualization; [`el2_supported`]).
    pub el2: bool,
}

/// The VM. It must outlive every [`Vcpu`], and guest memory must outlive it.
#[derive(Debug)]
pub struct Vm {
    fd: Arc<sys::VmFd>,
    pub(super) slots: Arc<Slots>,
    mmap_size: usize,
    mpidrs: Vec<u64>,
    el2: bool,
    /// Each vCPU's target and features; secondaries add POWER_OFF.
    init: sys::kvm_vcpu_init,
    /// The GICv3, once made, initialized once every vCPU exists ([`Vm::vcpus_created`]).
    gic: OnceLock<sys::DeviceFd>,
    /// Its ITS, where the machine has one.
    its: OnceLock<sys::DeviceFd>,
    /// KVM's VFIO device, made as the first VFIO file is added ([`Vm::add_vfio_file`]).
    pub(super) vfio: Arc<OnceLock<sys::DeviceFd>>,
    /// Each vCPU, by index, as it is made, not kept by the VM: what a restore reaches from
    /// the thread that finishes the machine, while the vCPUs' own threads wait (the
    /// prefetch, [`Vm::prefetch`]).
    vcpus: Mutex<Vec<sys::WeakVcpu>>,
}

impl Vm {
    pub fn new(config: VmConfig) -> Result<Vm> {
        install_kick_handler()?;
        let kvm = kvm().map_err(Error::Guest)?;
        let has = |cap| {
            kvm.check_extension(cap)
                .map(|n| n > 0)
                .map_err(call("KVM_CHECK_EXTENSION"))
        };
        // A width asked only of a KVM that sizes VMs: elsewhere every VM has 40 bits, and
        // any other type fails.
        let kind = if has(sys::CAP_ARM_VM_IPA_SIZE)? {
            u64::from(config.ipa_bits)
        } else {
            0
        };
        let fd = Arc::new(kvm.create_vm(kind).map_err(call("KVM_CREATE_VM"))?);
        // A data abort KVM cannot emulate, outside every memory slot with no access in its
        // syndrome, returned to the VMM, which says where it was: else KVM_RUN fails with
        // ENOSYS alone (api.rst 4.10, 7.20).
        if has(u64::from(sys::CAP_ARM_NISV_TO_USER))? {
            fd.enable_cap(sys::CAP_ARM_NISV_TO_USER)
                .map_err(call("KVM_ENABLE_CAP(KVM_CAP_ARM_NISV_TO_USER)"))?;
        }
        let mut init = fd.preferred_target().map_err(call("KVM_ARM_PREFERRED_TARGET"))?;
        let mut features = 1 << sys::VCPU_PSCI_0_2;
        // Pointer authentication where KVM gives both kinds, as the guest has it under
        // Hypervisor.framework: KVM takes both or neither (api.rst 4.82).
        if has(sys::CAP_ARM_PTRAUTH_ADDRESS)? && has(sys::CAP_ARM_PTRAUTH_GENERIC)? {
            features |= (1 << sys::VCPU_PTRAUTH_ADDRESS) | (1 << sys::VCPU_PTRAUTH_GENERIC);
        }
        if config.el2 {
            if !has(sys::CAP_ARM_EL2)? {
                return Err(Error::Guest(NO_EL2.into()));
            }
            features |= 1 << sys::VCPU_HAS_EL2;
        }
        if let Some(first) = init.features.first_mut() {
            *first |= features;
        }
        Ok(Vm {
            slots: Arc::new(Slots::new(kvm, fd.clone())),
            fd,
            mmap_size: kvm.vcpu_mmap_size().map_err(call("KVM_GET_VCPU_MMAP_SIZE"))?,
            mpidrs: config.mpidrs,
            el2: config.el2,
            init,
            gic: OnceLock::new(),
            its: OnceLock::new(),
            vfio: Arc::new(OnceLock::new()),
            vcpus: Mutex::new(Vec::new()),
        })
    }

    /// Creates the in-kernel GICv3 at `layout`'s places, its interrupts the machine's
    /// ([`NR_IRQS`]), and where the guest has EL2 its maintenance interrupt; it is
    /// initialized once every vCPU exists ([`Vm::vcpus_created`]). `layout`'s MSI frame is
    /// the machine's to emulate ([`MSI_FRAME_IN_KERNEL`]).
    pub fn create_gic(&self, layout: &GicLayout) -> Result<Gic> {
        if layout.msi.is_some() {
            return Err(Error::Guest(
                "KVM's GICv3 takes a PCI bus's MSIs at an ITS, not a GICv2m frame".into(),
            ));
        }
        let gic = self
            .fd
            .create_device(sys::DEV_TYPE_ARM_VGIC_V3)
            .map_err(call("KVM_CREATE_DEVICE"))?;
        let attr = call("KVM_SET_DEVICE_ATTR");
        gic.set_attr(sys::VGIC_GRP_ADDR, sys::VGIC_V3_ADDR_TYPE_DIST, &layout.dist_base)
            .map_err(&attr)?;
        gic.set_attr(
            sys::VGIC_GRP_ADDR,
            sys::VGIC_V3_ADDR_TYPE_REDIST,
            &layout.redist_base,
        )
        .map_err(&attr)?;
        gic.set_attr(sys::VGIC_GRP_NR_IRQS, 0, &NR_IRQS).map_err(&attr)?;
        if self.el2 {
            gic.set_attr(sys::VGIC_GRP_MAINT_IRQ, 0, &MAINTENANCE_INTID)
                .map_err(&attr)?;
        }
        self.gic
            .set(gic)
            .map_err(|_| Error::Guest("the VM has a GIC already".into()))?;
        // Its ITS (devices/arm-vgic-its.rst): its frame placed, then initialized, before
        // the GIC is, as every vCPU exists (KVM_DEV_ARM_VGIC_CTRL_INIT, which KVM's ITS
        // takes as done).
        if let Some(base) = layout.its {
            let its = self
                .fd
                .create_device(sys::DEV_TYPE_ARM_VGIC_ITS)
                .map_err(call("KVM_CREATE_DEVICE"))?;
            its.set_attr(sys::VGIC_GRP_ADDR, sys::VGIC_ITS_ADDR_TYPE, &base)
                .map_err(&attr)?;
            its.control(sys::VGIC_GRP_CTRL, sys::VGIC_CTRL_INIT)
                .map_err(&attr)?;
            self.its
                .set(its)
                .map_err(|_| Error::Guest("the VM has an ITS already".into()))?;
        }
        Ok(Gic(Arc::new(GicState {
            fd: self.fd.clone(),
            routes: Mutex::new(Vec::new()),
        })))
    }

    /// Initializes the GIC, once every vCPU exists and before any runs: its redistributors
    /// are the vCPUs' (arm-vgic-v3.rst, KVM_DEV_ARM_VGIC_CTRL_INIT).
    pub fn vcpus_created(&self) -> Result<()> {
        match self.gic.get() {
            Some(gic) => gic
                .control(sys::VGIC_GRP_CTRL, sys::VGIC_CTRL_INIT)
                .map_err(call("KVM_SET_DEVICE_ATTR")),
            None => Ok(()),
        }
    }

    /// Creates vCPU `index` on the calling thread, which owns it from then on: powered on
    /// for the boot vCPU, off for the others until their PSCI CPU_ON. vCPUs must be created
    /// in index order, as each takes the next redistributor (api.rst 4.7, `vcpu_idx`).
    pub fn create_vcpu(&self, index: usize) -> Result<Vcpu> {
        let &mpidr = self
            .mpidrs
            .get(index)
            .ok_or_else(|| Error::Guest(format!("no vCPU {index} in this VM")))?;
        let fd = self
            .fd
            .create_vcpu(index as u64, self.mmap_size)
            .map_err(call("KVM_CREATE_VCPU"))?;
        let mut init = self.init;
        if index > 0
            && let Some(first) = init.features.first_mut()
        {
            *first |= 1 << sys::VCPU_POWER_OFF;
        }
        fd.vcpu_init(&init).map_err(call("KVM_ARM_VCPU_INIT"))?;
        // KVM gives vCPU `index` the affinity the devicetree names (arch::aarch64::mpidr);
        // where they differ, PSCI and the GIC would not reach the CPU the guest means.
        let given = fd
            .get_reg(sys::sysreg(sysreg::MPIDR_EL1))
            .map_err(call("KVM_GET_ONE_REG"))?;
        if given & MPIDR_AFFINITY != mpidr {
            return Err(Error::Guest(format!(
                "vCPU {index}: KVM's MPIDR {given:#x}, where the devicetree says {mpidr:#x}"
            )));
        }
        lock(&self.vcpus).push(fd.weak());
        let thread = super::this_thread();
        self.slots.dirty.add_vcpu(&fd)?;
        Ok(Vcpu {
            kicker: Kicker {
                run: fd.run.clone(),
                thread: thread.clone(),
            },
            dirty: self.slots.dirty.clone(),
            fd,
            thread,
        })
    }

    /// The GIC's state, its registers as KVM gives them (`gic`): every vCPU must be out of
    /// the guest and out of every other call of KVM's, as KVM takes them all to read it
    /// (arm-vgic-v3.rst: EBUSY). Where the machine has an ITS, a PCI bus's (D154, D214),
    /// its LPIs' pending state and the ITS's tables are written to guest memory first, as
    /// a snapshot then saves them with it, and its registers kept beside the GIC's.
    pub fn save_gic(&self) -> Result<Vec<u8>> {
        let gic = self
            .gic
            .get()
            .ok_or_else(|| Error::Guest("the VM has no GIC".into()))?;
        let its = match self.its.get() {
            Some(its) => {
                gic.control(sys::VGIC_GRP_CTRL, sys::VGIC_SAVE_PENDING_TABLES)
                    .map_err(|e| Error::Guest(format!("the GIC's LPIs' pending tables: {e}")))?;
                Some(gic::its_save(its)?)
            }
            None => None,
        };
        let regs = gic::save(gic, &self.mpidrs, its.is_some())?;
        let mut w = crate::snapshot::codec::Writer::default();
        w.bytes(&regs);
        w.bool(its.is_some());
        w.bytes(its.as_deref().unwrap_or_default());
        Ok(w.into_bytes())
    }

    /// Restores [`save_gic`](Self::save_gic)'s state into this VM's GIC, initialized once
    /// every vCPU exists ([`Vm::vcpus_created`]), before any runs the guest, with every vCPU
    /// out of every call of KVM's: its ITS's after its redistributors', as
    /// arm-vgic-its.rst's restore sequence has it. A state of an ITS restores only into a
    /// machine with one, and the other way round.
    pub fn restore_gic(&self, state: &[u8]) -> Result<()> {
        let gic = self
            .gic
            .get()
            .ok_or_else(|| Error::Guest("the VM has no GIC".into()))?;
        let mut r = crate::snapshot::codec::Reader::new(state);
        let decoded = (|| {
            let regs = r.bytes(usize::MAX)?.to_vec();
            let has_its = r.bool()?;
            let its = r.bytes(usize::MAX)?.to_vec();
            r.finish()?;
            Ok((regs, has_its.then_some(its)))
        })();
        let (regs, its) = decoded.map_err(|crate::snapshot::codec::DecodeError(e)| {
            Error::Guest(format!("the snapshot's GIC: {e}"))
        })?;
        gic::restore(gic, &regs, self.mpidrs.len(), its.is_some())?;
        match (its, self.its.get()) {
            (Some(state), Some(its)) => gic::its_restore(its, &state),
            (None, None) => Ok(()),
            (Some(_), None) => Err(Error::Guest(
                "the snapshot's GIC has an ITS; this machine's has none".into(),
            )),
            (None, Some(_)) => Err(Error::Guest(
                "this machine's GIC has an ITS; the snapshot's has none".into(),
            )),
        }
    }

    /// Runs the prefetch program on vCPU 0 over `pages` (`prefetch`), `memory` saying of
    /// each page whether it is guest memory, and writable, then restores `first`, vCPU 0's
    /// state, over all it set. For a restore once every vCPU exists, the GIC initialized
    /// ([`Vm::vcpus_created`]), from a thread that is not vCPU 0's, which waits meanwhile.
    /// Returns how many pages it touched; its failure is the VM's, as HVF's is.
    pub fn prefetch(
        &self,
        pages: &[Touch],
        first: &VcpuState,
        memory: impl Fn(u64) -> Option<bool>,
    ) -> Result<usize> {
        let mut fd = lock(&self.vcpus)
            .first()
            .and_then(sys::WeakVcpu::upgrade)
            .ok_or_else(|| Error::Guest("vCPU 0 is gone".into()))?;
        let touched = prefetch::run(self, &mut fd, pages, memory);
        let restored = state::restore(&fd, first);
        let touched = touched?;
        restored.map(|()| touched)
    }
}

/// The guest's virtual counter, which a restore sets for the whole VM, once, as its vCPUs
/// are released (KVM_REG_ARM_TIMER_CNT, of any of them, sets the VM's one offset): a
/// handle of vCPU 0's that does not keep it.
#[derive(Debug, Clone)]
pub struct Counter(sys::WeakVcpu);

impl Counter {
    /// Sets the guest's virtual counter to `value` now, every vCPU's: the counter goes on
    /// from where the snapshot's guest left it. Nothing where the vCPU has gone.
    pub fn set(&self, value: u64) -> Result<()> {
        match self.0.upgrade() {
            Some(fd) => fd
                .set_reg(sys::REG_TIMER_CNT, value)
                .map_err(call("KVM_SET_ONE_REG")),
            None => Ok(()),
        }
    }
}

/// The host counter guest counters are offset from, now: CNTVCT_EL0, which Linux gives
/// its processes (arch_timer: CNTKCTL_EL1.EL0VCTEN).
pub fn host_counter() -> u64 {
    let value: u64;
    // SAFETY: reads a counter register EL0 may read; no memory is touched.
    unsafe { std::arch::asm!("mrs {0}, cntvct_el0", out(reg) value, options(nomem, nostack)) };
    value
}

/// A vCPU, run by the thread that created it.
#[derive(Debug)]
pub struct Vcpu {
    fd: sys::VcpuFd,
    kicker: Kicker,
    /// Cleared on drop, so no kick can signal a thread that no longer runs this vCPU.
    pub(super) thread: Arc<Mutex<Option<Thread>>>,
    /// Its VM's watch of the guest's writes, which empties its dirty ring as it fills
    /// (D176 part 7).
    dirty: Arc<super::Dirty>,
}

impl Vcpu {
    pub fn kicker(&self) -> Kicker {
        self.kicker.clone()
    }

    /// Makes this the boot vCPU: it enters at `entry` on its first `run`, at EL1h (or
    /// EL2h where the VM has EL2) with DAIF masked and its MMU off, as KVM resets it
    /// (api.rst 4.82) and Linux boots (booting.rst).
    pub fn boot(&mut self, entry: Entry) -> Result<()> {
        self.fd
            .set_reg(sys::REG_PC, entry.pc)
            .map_err(call("KVM_SET_ONE_REG"))?;
        self.fd
            .set_reg(sys::reg_x(0), entry.x0)
            .map_err(call("KVM_SET_ONE_REG"))
    }

    /// Runs the guest until it powers off, resets, or a kick arrives.
    pub fn run(&mut self, io: &dyn Io) -> Result<Exit> {
        super::run(&mut self.fd, io, &self.dirty)
    }

    /// The CPU identity the guest sees: ID registers by encoding.
    pub fn cpu_id(&self) -> Result<Vec<(u16, u64)>> {
        ID_REGS
            .iter()
            .map(|&r| {
                let value = self.fd.get_reg(sys::sysreg(r)).map_err(call("KVM_GET_ONE_REG"))?;
                Ok((r, value))
            })
            .collect()
    }

    /// Tells the guest the CPU `id` describes, each ID register set and read back (KVM takes
    /// its writable fields, api.rst 4.68, "Writable ID registers"): a guest resumed on another
    /// CPU than its snapshot's goes on with the one it found (D176 part 6).
    pub fn set_cpu_id(&mut self, id: &[(u16, u64)]) -> Result<()> {
        for &(r, v) in id {
            self.fd
                .set_reg(sys::sysreg(r), v)
                .map_err(call("KVM_SET_ONE_REG"))?;
            let now = self.fd.get_reg(sys::sysreg(r)).map_err(call("KVM_GET_ONE_REG"))?;
            if now != v {
                return Err(Error::Guest(format!(
                    "{} stays {now:#x} where its guest's is {v:#x}",
                    crate::arch::aarch64::cpu::name(r)
                )));
            }
        }
        Ok(())
    }

    /// Captures the vCPU's state (`state`). Call on the owning thread, with the vCPU out of
    /// the guest.
    pub fn save_state(&self) -> Result<VcpuState> {
        state::save(&self.fd)
    }

    /// Loads captured state into this freshly created vCPU. The guest counter is set for
    /// the whole VM as the vCPUs are released ([`Counter`]).
    pub fn restore_state(&mut self, st: &VcpuState) -> Result<()> {
        state::restore(&self.fd, st)
    }

    /// The guest's virtual counter now.
    pub fn guest_counter(&self) -> Result<u64> {
        self.fd
            .get_reg(sys::REG_TIMER_CNT)
            .map_err(call("KVM_GET_ONE_REG"))
    }

    /// What sets the guest's counter at the release ([`Counter`]).
    pub fn counter(&self) -> Counter {
        Counter(self.fd.weak())
    }
}

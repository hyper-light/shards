//! WinHvPlatform.dll, the Windows Hypervisor Platform's API, for the subset shards uses, and
//! WinHvEmulation.dll, its instruction emulator: their types are windows-sys's
//! (Win32_System_Hypervisor, from WinHvPlatform.h and WinHvEmulation.h), their functions
//! looked up the first time any is called, not linked. A binary linked to them starts only
//! where the optional feature "Windows Hypervisor Platform" is on; shards' every command but
//! a VM's must start everywhere, and say why a VM cannot.

#![allow(non_snake_case)]

use std::ffi::c_void;

use windows_sys::Win32::Foundation::HANDLE;
pub use windows_sys::Win32::System::Hypervisor::*;
use windows_sys::Win32::System::LibraryLoader::{
    GetProcAddress, LOAD_LIBRARY_SEARCH_SYSTEM32, LoadLibraryExW,
};
use windows_sys::core::HRESULT;

/// What a call returns when the DLL, or the function, is not there: E_NOTIMPL.
pub const MISSING: HRESULT = 0x8000_4001_u32 as HRESULT;

macro_rules! winhv {
    ($dll:literal, $table:ident; $( fn $name:ident($($arg:ident: $ty:ty),* $(,)?); )*) => {
        struct $table {
            $( $name: Option<unsafe extern "system" fn($($ty),*) -> HRESULT>, )*
        }

        impl $table {
            fn get() -> &'static $table {
                static TABLE: std::sync::OnceLock<$table> = std::sync::OnceLock::new();
                TABLE.get_or_init($table::load)
            }

            fn load() -> $table {
                let name: Vec<u16> = $dll.encode_utf16().chain([0]).collect();
                // SAFETY: a NUL-terminated name, loaded from System32 alone and kept for the
                // process's life.
                let module = unsafe { LoadLibraryExW(name.as_ptr(), std::ptr::null_mut(), LOAD_LIBRARY_SEARCH_SYSTEM32) };
                let find = |name: &[u8]| -> *const c_void {
                    if module.is_null() {
                        return std::ptr::null();
                    }
                    // SAFETY: a live module and a NUL-terminated name.
                    match unsafe { GetProcAddress(module, name.as_ptr()) } {
                        Some(f) => f as *const c_void,
                        None => std::ptr::null(),
                    }
                };
                $table {
                    $( $name: {
                        let at = find(concat!(stringify!($name), "\0").as_bytes());
                        // SAFETY: the DLL's function of this name, whose signature the macro's
                        // line for it gives, from its header.
                        (!at.is_null()).then(|| unsafe {
                            std::mem::transmute::<*const c_void, unsafe extern "system" fn($($ty),*) -> HRESULT>(at)
                        })
                    }, )*
                }
            }
        }

        $(
            #[doc = concat!($dll, "'s function of this name.")]
            ///
            /// # Safety
            ///
            /// As the platform's own: its arguments as its header asks.
            pub unsafe fn $name($($arg: $ty),*) -> HRESULT {
                match $table::get().$name {
                    // SAFETY: the platform's function, called as its header asks.
                    Some(f) => unsafe { f($($arg),*) },
                    None => MISSING,
                }
            }
        )*
    };
}

/// Whether WinHvPlatform.dll is on this host: the optional feature is on, and with it
/// every function of the DLL.
pub fn loaded() -> bool {
    Platform::get().WHvGetCapability.is_some()
}

winhv! {
    "WinHvPlatform.dll", Platform;
    fn WHvGetCapability(code: WHV_CAPABILITY_CODE, buffer: *mut c_void, size: u32, written: *mut u32);
    fn WHvCreatePartition(partition: *mut WHV_PARTITION_HANDLE);
    fn WHvSetupPartition(partition: WHV_PARTITION_HANDLE);
    fn WHvDeletePartition(partition: WHV_PARTITION_HANDLE);
    fn WHvSetPartitionProperty(partition: WHV_PARTITION_HANDLE, code: WHV_PARTITION_PROPERTY_CODE, value: *const c_void, size: u32);
    fn WHvGetPartitionProperty(partition: WHV_PARTITION_HANDLE, code: WHV_PARTITION_PROPERTY_CODE, value: *mut c_void, size: u32, written: *mut u32);
    fn WHvSuspendPartitionTime(partition: WHV_PARTITION_HANDLE);
    fn WHvResumePartitionTime(partition: WHV_PARTITION_HANDLE);
    fn WHvMapGpaRange(partition: WHV_PARTITION_HANDLE, source: *const c_void, gpa: u64, size: u64, flags: WHV_MAP_GPA_RANGE_FLAGS);
    fn WHvUnmapGpaRange(partition: WHV_PARTITION_HANDLE, gpa: u64, size: u64);
    fn WHvQueryGpaRangeDirtyBitmap(partition: WHV_PARTITION_HANDLE, gpa: u64, size: u64, bitmap: *mut u64, bitmap_size: u32);
    fn WHvAdviseGpaRange(partition: WHV_PARTITION_HANDLE, ranges: *const WHV_MEMORY_RANGE_ENTRY, count: u32, advice: WHV_ADVISE_GPA_RANGE_CODE, buffer: *const c_void, size: u32);
    fn WHvCreateVirtualProcessor(partition: WHV_PARTITION_HANDLE, index: u32, flags: u32);
    fn WHvDeleteVirtualProcessor(partition: WHV_PARTITION_HANDLE, index: u32);
    fn WHvRunVirtualProcessor(partition: WHV_PARTITION_HANDLE, index: u32, exit: *mut c_void, size: u32);
    fn WHvCancelRunVirtualProcessor(partition: WHV_PARTITION_HANDLE, index: u32, flags: u32);
    fn WHvGetVirtualProcessorRegisters(partition: WHV_PARTITION_HANDLE, index: u32, names: *const WHV_REGISTER_NAME, count: u32, values: *mut WHV_REGISTER_VALUE);
    fn WHvSetVirtualProcessorRegisters(partition: WHV_PARTITION_HANDLE, index: u32, names: *const WHV_REGISTER_NAME, count: u32, values: *const WHV_REGISTER_VALUE);
    fn WHvGetVirtualProcessorState(partition: WHV_PARTITION_HANDLE, index: u32, kind: WHV_VIRTUAL_PROCESSOR_STATE_TYPE, buffer: *mut c_void, size: u32, written: *mut u32);
    fn WHvSetVirtualProcessorState(partition: WHV_PARTITION_HANDLE, index: u32, kind: WHV_VIRTUAL_PROCESSOR_STATE_TYPE, buffer: *const c_void, size: u32);
    fn WHvRequestInterrupt(partition: WHV_PARTITION_HANDLE, control: *const WHV_INTERRUPT_CONTROL, size: u32);
    fn WHvGetVirtualProcessorCpuidOutput(partition: WHV_PARTITION_HANDLE, index: u32, eax: u32, ecx: u32, output: *mut WHV_CPUID_OUTPUT);
    fn WHvTranslateGva(partition: WHV_PARTITION_HANDLE, index: u32, gva: u64, flags: WHV_TRANSLATE_GVA_FLAGS, result: *mut WHV_TRANSLATE_GVA_RESULT, gpa: *mut u64);
    fn WHvGetInterruptTargetVpSet(partition: WHV_PARTITION_HANDLE, destination: u64, mode: WHV_INTERRUPT_DESTINATION_MODE, vps: *mut u32, count: u32, written: *mut u32);
    // Virtual PCI devices, a host's function assigned to a partition (D154).
    fn WHvAllocateVpciResource(provider: *const windows_sys::core::GUID, flags: WHV_ALLOCATE_VPCI_RESOURCE_FLAGS, descriptor: *const c_void, size: u32, resource: *mut HANDLE);
    fn WHvCreateVpciDevice(partition: WHV_PARTITION_HANDLE, id: u64, resource: HANDLE, flags: WHV_CREATE_VPCI_DEVICE_FLAGS, event: HANDLE);
    fn WHvDeleteVpciDevice(partition: WHV_PARTITION_HANDLE, id: u64);
    fn WHvGetVpciDeviceProperty(partition: WHV_PARTITION_HANDLE, id: u64, code: WHV_VPCI_DEVICE_PROPERTY_CODE, buffer: *mut c_void, size: u32, written: *mut u32);
    // Its DEVICE_POWER_STATE (wdm.h): D0 is 1, D3 4.
    fn WHvSetVpciDevicePowerState(partition: WHV_PARTITION_HANDLE, id: u64, state: i32);
    fn WHvMapVpciDeviceMmioRanges(partition: WHV_PARTITION_HANDLE, id: u64, count: *mut u32, mappings: *mut *mut WHV_VPCI_MMIO_MAPPING);
    fn WHvUnmapVpciDeviceMmioRanges(partition: WHV_PARTITION_HANDLE, id: u64);
    fn WHvReadVpciDeviceRegister(partition: WHV_PARTITION_HANDLE, id: u64, register: *const WHV_VPCI_DEVICE_REGISTER, data: *mut c_void);
    fn WHvWriteVpciDeviceRegister(partition: WHV_PARTITION_HANDLE, id: u64, register: *const WHV_VPCI_DEVICE_REGISTER, data: *const c_void);
    fn WHvMapVpciDeviceInterrupt(partition: WHV_PARTITION_HANDLE, id: u64, index: u32, count: u32, target: *const WHV_VPCI_INTERRUPT_TARGET, address: *mut u64, data: *mut u32);
    fn WHvUnmapVpciDeviceInterrupt(partition: WHV_PARTITION_HANDLE, id: u64, index: u32);
}

winhv! {
    "WinHvEmulation.dll", Emulation;
    fn WHvEmulatorCreateEmulator(callbacks: *const WHV_EMULATOR_CALLBACKS, emulator: *mut *mut c_void);
    fn WHvEmulatorDestroyEmulator(emulator: *const c_void);
    fn WHvEmulatorTryMmioEmulation(emulator: *const c_void, context: *const c_void, vp: *const WHV_VP_EXIT_CONTEXT, access: *const WHV_MEMORY_ACCESS_CONTEXT, status: *mut WHV_EMULATOR_STATUS);
}

/// A register value at the 16 bytes' alignment WinHvPlatform.h gives WHV_REGISTER_VALUE
/// (`DECLSPEC_ALIGN(16)`) and windows-sys's declaration does not: handed over 8-aligned,
/// arrays of them fault in the DLL (PM M197).
#[repr(C, align(16))]
#[derive(Clone, Copy, Default)]
pub struct Value(pub WHV_REGISTER_VALUE);

/// The exit context at the same alignment, which holds register values.
#[repr(C, align(16))]
#[derive(Clone, Copy, Default)]
pub struct ExitContext(pub WHV_RUN_VP_EXIT_CONTEXT);

impl std::fmt::Debug for Value {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Value({:#x})", self.get())
    }
}

impl std::fmt::Debug for ExitContext {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "ExitContext({:#x})", self.0.ExitReason)
    }
}

impl Value {
    pub fn u64(v: u64) -> Value {
        let mut r = WHV_REGISTER_VALUE::default();
        r.Reg64 = v;
        Value(r)
    }

    /// Its 64 bits.
    pub fn get(&self) -> u64 {
        // SAFETY: every register value's first 8 bytes are a u64's, whatever it holds.
        unsafe { self.0.Reg64 }
    }
}

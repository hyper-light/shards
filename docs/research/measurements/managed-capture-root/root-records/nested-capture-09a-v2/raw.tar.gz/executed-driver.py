"""ROOT: existing nested ARM64 KVM managed-output gate, not a new VM mechanism."""
from pathlib import Path
import hashlib
import json
import os
import plistlib
import shutil
import signal
import subprocess
import time

repo = Path.cwd()
home = Path.home()
source = "09a187d2a55522d59a79b0fc21ac9378f25c0fb9"
out = home / "root-managed-capture-nested-09a-v1"
out.mkdir(exist_ok=False)
(out / "executed-driver.py").write_bytes(globals()["ROOT_DRIVER_BYTES"])
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == source
assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"])
rules = (repo / "docs/development-rules.md").read_bytes()
assert hashlib.sha256(rules).hexdigest() == "df2acf47cf92996e9435f9a4988f10e9e7aaa21ca952a00069c044c7ed4f13d3"
assert shutil.disk_usage(home).free >= 30 * 1024**3
assert os.uname().machine == "arm64"
(out / "empty-docker").mkdir()
env = os.environ.copy()
for key in ["SHARDS_HELPERS", "SHARDS_HELPERS_DIR", "SHARDS_INIT_BINARY", "SHARDS_VM_BINARY", "SHARDS_TEST_GUESTS", "SHARDS_SERVER_BINARY", "SHARDS_TEST_KERNEL", "SHARDS_TEST_NESTED_KERNEL", "SHARDS_KERNEL", "SHARDS_INIT", "SHARDS_L1_PCI_TESTS"]:
    env.pop(key, None)
env.update(CARGO_BUILD_JOBS="4", CARGO_TARGET_DIR=str(out / "target"), DOCKER_CONFIG=str(out / "empty-docker"))
identity = {
    "role": "coordinator",
    "source": source,
    "policy_main": "ca3ab10c151aa5539e757f1cc76029746ccbb561",
    "policy_sha256": hashlib.sha256(rules).hexdigest(),
    "uname": list(os.uname()),
    "load": os.getloadavg(),
    "free_bytes": shutil.disk_usage(home).free,
    "admission": "8CPU/32GiB/96GiB; cargo-j4; existing outer guest 8vCPU/24576MiB",
    "not_a_hard_host_quota": True,
    "source_sha256": {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in ["Cargo.lock", "crates/remote/src/managed.rs", "crates/shards/src/daemon/managed.rs", "crates/shards/tests/boot.rs", "crates/shards/tests/managed_output.rs", "crates/shards/tests/common/mod.rs"]},
}
(out / "identity.json").write_text(json.dumps(identity, indent=2) + "\n")


def run(name, command, seconds):
    assert shutil.disk_usage(home).free >= 30 * 1024**3
    (out / (name + ".command.json")).write_text(json.dumps(command) + "\n")
    began = time.monotonic()
    timed = False
    with (out / (name + ".stdout")).open("xb") as stdout, (out / (name + ".stderr")).open("xb") as stderr:
        try:
            child = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            rc = child.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            # The direct child remains unreaped, so this owned process-group ID
            # cannot have been recycled before the group termination request.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=15)
            rc, timed = 124, True
        finally:
            # launchd is not a child-process tree. Retire only the job named by
            # this unique private record, including when its waiting shell fails.
            if name == "nested-kvm-managed-output":
                plist = out / "nested-launchd.plist"
                if plist.is_file():
                    definition = plistlib.loads(plist.read_bytes())
                    label = definition["Label"]
                    assert label.startswith("com.hyperlight.shards.measure.")
                    assert str(out / "nested-launchd.log") == definition["StandardOutPath"]
                    cleaned = subprocess.run(["launchctl", "bootout", "gui/" + str(os.getuid()) + "/" + label], capture_output=True, timeout=30)
                    (out / "launchd-cleanup.json").write_text(json.dumps({"label": label, "bootout_exit": cleaned.returncode, "stdout": cleaned.stdout.decode(errors="replace"), "stderr": cleaned.stderr.decode(errors="replace"), "whole_population_return": "Unknown"}, indent=2) + "\n")
    record = {"exit_code": rc, "timeout": timed, "elapsed_seconds": time.monotonic() - began, "free_bytes": shutil.disk_usage(home).free, "whole_population_kernel_return": "Unknown"}
    (out / (name + ".result.json")).write_text(json.dumps(record, indent=2) + "\n")
    print(name, json.dumps(record), flush=True)
    if rc:
        print((out / (name + ".stderr")).read_text(errors="replace")[-6000:], flush=True)
    assert rc == 0


run("policy", ["python3", "scripts/check-development-policy"], 60)
run("host-boot-carried-build", ["lockf", "/tmp/g121-mac.lock", "cargo", "test", "--locked", "--profile", "test-release", "-p", "shards", "--test", "boot", "--no-run", "--message-format=json", "-j4"], 2400)
command = ["lockf", "/tmp/g121-mac.lock", "/bin/zsh", "docs/research/measurements/macos-sched/launchd-run.sh", str(out / "nested-launchd"), "/usr/bin/env", "CARGO_BUILD_JOBS=4", "CARGO_TARGET_DIR=" + env["CARGO_TARGET_DIR"], "DOCKER_CONFIG=" + env["DOCKER_CONFIG"], "SHARDS_L1_TESTS=managed_output", "SHARDS_L1_CONSOLE=" + str(out / "nested-console.log"), "SHARDS_REQUIRE_VMS=1", "cargo", "test", "--locked", "--profile", "test-release", "-p", "shards", "--test", "boot", "snapshot_tests_pass_on_a_kvm_host_of_this_architecture", "--", "--exact", "--nocapture", "--test-threads=1"]
# Existing fixture: first native EL2 probe, normal static Linux build, then one
# 45-minute outer VM. No PCI/driver/device-assignment scenario is selected.
run("nested-kvm-managed-output", command, 7200)
console = out / "nested-console.log"
launch = (out / "nested-launchd.log").read_text(errors="replace")
assert "SKIP:" not in launch
assert console.is_file()
text = console.read_text(errors="replace")
assert "25 passed; 0 failed; 10 ignored;" in text
assert "E2E STATUS /e2e/tests/managed_output exit status: 0" in text
assert "SKIP:" not in text
assert "SHARDS-TEST PASS" in text
assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"])
(out / "completed.json").write_text(json.dumps({"source": source, "ordinary_kvm_arm64": "25passed/0failed/10ignored", "management_layer_complete": False}, indent=2) + "\n")
print("COMPLETE", source, flush=True)

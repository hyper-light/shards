// One path-loaded Reader and its own codec types, shared with the reference.
#[path = "../../../../../crates/init/src/metrics.rs"]
pub mod metrics;
pub use metrics::Reader;
pub use metrics::otlp::*;

//! What packing and unpacking ask of the system, on Unix and on Windows.

use crate::tar::Time;

#[cfg(unix)]
mod unix;
#[cfg(unix)]
pub(crate) use unix::*;

#[cfg(windows)]
mod windows;
#[cfg(windows)]
pub(crate) use windows::*;

/// A file's type, as Go's FileMode tells it. Windows has no devices or FIFOs to pack.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(windows, allow(dead_code))]
pub enum FileKind {
    File,
    Dir,
    Symlink,
    Char,
    Block,
    Fifo,
    Socket,
    /// Go's ModeIrregular, or a type Go names none of.
    Other,
}

/// What lstat says of a file. Windows has no owners or device numbers to pack.
#[derive(Debug, Clone)]
#[cfg_attr(windows, allow(dead_code))]
pub struct Stat {
    pub kind: FileKind,
    /// `st_mode` on Unix; Go's permission bits on Windows.
    pub mode: u32,
    pub uid: u32,
    pub gid: u32,
    pub size: u64,
    pub mtime: Time,
    /// Which file it is on its device: `st_ino` on Unix; on Windows its 128-bit file ID
    /// and `dev` its volume's serial number, asked of a file of more than one name alone,
    /// 0 for one of one.
    pub ino: u128,
    pub dev: u64,
    pub nlink: u64,
    /// The numbers of the device it is (`st_rdev`'s major and minor), 0 where it is none.
    pub major: i64,
    pub minor: i64,
}

//! A run joining the workload's microVM and network (`--network container:NAME`, D119):
//! its image a range of the microVM's join disk, its root that image under a tmpfs overlay,
//! its mount, PID, IPC, UTS and cgroup namespaces its own unless it asks to share them
//! (D156), its network namespace the workload's. It takes the workload's hostname and its
//! `/etc/hostname`, `/etc/hosts` and `/etc/resolv.conf`, the same files.

use std::ffi::CString;
use std::fs::File;
use std::io::{self, Write};
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::time::{Duration, Instant};

/// Where a joiner's image lies on the join disk, the workload whose network it joins,
/// where its writable layer from before lies on the disk, if it has one to put back (D37),
/// and whose PID namespace its processes are in.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Join {
    pub offset: u64,
    pub len: u64,
    pub workload: libc::pid_t,
    pub layer: Option<(u64, u64)>,
    pub pid: Pid,
    /// A reaper first in a PID namespace of its own (`--init`).
    pub init: bool,
    /// Its IPC namespace and /dev/shm (D156).
    pub ipc: Ipc,
    /// The microVM's UTS namespace, its workload's, rather than one of its own (`--uts
    /// host`).
    pub uts_host: bool,
    /// The microVM's cgroup namespace, rather than one rooted at its cgroup (`--cgroupns
    /// host`).
    pub cgroupns_host: bool,
    /// Its writable layer's size in bytes (`--storage-opt size=`), else the tmpfs default.
    pub rw_size: Option<u64>,
    /// Its binds of its microVM's own files (D181), each a path of the workload's files and
    /// where it goes in its own.
    pub own_binds: Vec<OwnBind>,
    /// A member of its microVM's switch, made by its microVM's engine (D181), where the
    /// workload's network would be its own otherwise; with its own hostname.
    pub member: Option<MemberNet>,
    /// A network namespace of its own with its loopback alone (`--network none`).
    pub own_net_none: bool,
    /// The process of another joiner whose network namespace and names it shares
    /// (`--network container:X` of one its microVM's engine gave a namespace of its own,
    /// D181): its UTS namespace, and its hostname, hosts and resolv.conf, the same files.
    pub net_of: Option<libc::pid_t>,
    pub hostname: Vec<u8>,
    /// Its own `/etc/hosts` lines after its defaults (`--add-host`) and `/etc/resolv.conf`,
    /// where it has a network of its own.
    pub hosts: Vec<Vec<u8>>,
    pub resolv: Option<Vec<u8>>,
}

/// A joiner's membership of its microVM's switch (D181): init's descriptor of the network
/// namespace made for it, linked to the switch through its gate, which it enters; its
/// address on each of its networks and its names there, which its own `/etc/hosts` gives
/// it; and whether it asks the agents' resolver.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MemberNet {
    pub ns: std::os::fd::RawFd,
    pub on: Vec<(std::net::Ipv4Addr, Vec<String>)>,
    pub dns: bool,
}

/// A bind of a microVM's own files into a joiner its engine made (D181): `source`, a path
/// in the workload's mount namespace, made there first where it is missing (`create`, as
/// `-v` makes a host's), at `target` in the joiner's root, read-only unless `writable`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OwnBind {
    pub source: String,
    pub target: String,
    pub writable: bool,
    pub create: bool,
}

/// The binds of its microVM's own files `setup` gives a joiner (`own-bind=SRC\0DST\0FLAGS`).
pub fn own_binds(setup: &[Vec<u8>]) -> Result<Vec<OwnBind>, String> {
    setup
        .iter()
        .filter_map(|e| e.strip_prefix(b"own-bind="))
        .map(|e| {
            let text = std::str::from_utf8(e).map_err(|_| "a bind's paths are not UTF-8".to_string())?;
            let mut parts = text.split('\0');
            let (Some(source), Some(target), Some(flags), None) =
                (parts.next(), parts.next(), parts.next(), parts.next())
            else {
                return Err(format!("a malformed bind of its microVM's files: {text:?}"));
            };
            if !source.starts_with('/') || !target.starts_with('/') {
                return Err(format!(
                    "a bind of its microVM's files names a relative path: {text:?}"
                ));
            }
            let flags: Vec<&str> = flags.split(',').collect();
            Ok(OwnBind {
                source: source.to_string(),
                target: target.to_string(),
                writable: flags.contains(&"rw"),
                create: flags.contains(&"create"),
            })
        })
        .collect()
}

/// Whose IPC namespace and /dev/shm a joiner has (D156): its own (`private`, `shareable`);
/// its own, with no /dev/shm (`none`); the microVM's, init's (`host`); or those of the
/// workload or another joiner, its command's process here, which it shares
/// (`container:NAME`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Ipc {
    Own,
    None,
    Host,
    Workload,
    Joiner(libc::pid_t),
}

/// The IPC namespace `setup` asks for: another joiner's found by its exec's id among
/// `joiners`, each an id and its command's process.
pub fn ipc(setup: &[Vec<u8>], joiners: &[(u32, libc::pid_t)]) -> Result<Ipc, String> {
    for entry in setup {
        match entry.as_slice() {
            b"ipc=none" => return Ok(Ipc::None),
            b"ipc=host" => return Ok(Ipc::Host),
            b"ipc=workload" => return Ok(Ipc::Workload),
            _ => {}
        }
        if let Some(id) = entry.strip_prefix(b"ipc=joiner=") {
            let id: u32 = std::str::from_utf8(id)
                .ok()
                .and_then(|id| id.parse().ok())
                .ok_or("a malformed ipc=joiner entry")?;
            return joiners
                .iter()
                .find(|(j, _)| *j == id)
                .map(|&(_, pid)| Ipc::Joiner(pid))
                .ok_or_else(|| "the run whose IPC namespace it shares is not running".to_string());
        }
    }
    Ok(Ipc::Own)
}

/// Whether setup `entry` is one a joiner's root and namespaces are built by ([`build`]),
/// rather than one its standby applies or init does for the microVM's own run.
pub fn built_by(entry: &[u8]) -> bool {
    entry.starts_with(b"ipc=")
        || entry == b"uts=host"
        || entry == b"cgroupns=host"
        || entry.starts_with(b"rw-size=")
        || entry.starts_with(b"own-bind=")
        || entry.starts_with(b"own-net=")
        || entry == b"own-net-none"
        || entry.starts_with(b"own-publish=")
}

/// The writable layer's size `setup` asks for, in bytes.
pub fn rw_size(setup: &[Vec<u8>]) -> Result<Option<u64>, String> {
    setup
        .iter()
        .find_map(|e| e.strip_prefix(b"rw-size="))
        .map(|n| {
            std::str::from_utf8(n)
                .ok()
                .and_then(|n| n.parse().ok())
                .ok_or_else(|| "a malformed rw-size entry".to_string())
        })
        .transpose()
}

/// Whose PID namespace a joiner's processes are in: one of its own, its command that
/// namespace's PID 1, as a container's is; the workload's whose network it joins
/// (`--pid container:NAME`, `pid=workload`); that of another joiner of the microVM, its
/// command's process here (`--pid container:NAME` of a joiner, `pid=joiner=ID`); or the
/// microVM's own, init's (`--pid host`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Pid {
    Own,
    Workload,
    Joiner(libc::pid_t),
    Host,
}

/// The PID namespace `setup` asks for: another joiner's found by its exec's id among
/// `joiners`, each an id and its command's process.
/// The process of the joiner whose network namespace `setup` says a joiner shares
/// (`net=joiner=ID`, D181), one of `joiners`; none for the workload's.
pub fn net_of(setup: &[Vec<u8>], joiners: &[(u32, libc::pid_t)]) -> Result<Option<libc::pid_t>, String> {
    let Some(id) = setup.iter().find_map(|e| e.strip_prefix(b"net=joiner=")) else {
        return Ok(None);
    };
    let id: u32 = std::str::from_utf8(id)
        .ok()
        .and_then(|id| id.parse().ok())
        .ok_or("a malformed net=joiner entry")?;
    joiners
        .iter()
        .find(|(j, _)| *j == id)
        .map(|&(_, pid)| Some(pid))
        .ok_or_else(|| "the container whose network it joins has ended".to_string())
}

pub fn pid(setup: &[Vec<u8>], joiners: &[(u32, libc::pid_t)]) -> Result<Pid, String> {
    if setup.iter().any(|e| e == b"pid=host") {
        return Ok(Pid::Host);
    }
    if setup.iter().any(|e| e == b"pid=workload") {
        return Ok(Pid::Workload);
    }
    let Some(id) = setup.iter().find_map(|e| e.strip_prefix(b"pid=joiner=")) else {
        return Ok(Pid::Own);
    };
    let id: u32 = std::str::from_utf8(id)
        .ok()
        .and_then(|id| id.parse().ok())
        .ok_or("a malformed pid=joiner entry")?;
    joiners
        .iter()
        .find(|(j, _)| *j == id)
        .map(|&(_, pid)| Pid::Joiner(pid))
        .ok_or_else(|| "the container whose PID namespace it joins is not running".to_string())
}

/// An image's user database, `/etc/passwd` and `/etc/group`, where it has them.
pub type Users = (Option<Vec<u8>>, Option<Vec<u8>>);

/// A joiner's layers, its image's and its writable one, each a directory's `O_PATH`
/// descriptor kept from before its root moved over them, as init keeps the workload's
/// (changes.rs, `keep`): what its diff, size and commit read.
#[derive(Debug)]
pub struct Kept {
    pub lower: OwnedFd,
    pub upper: OwnedFd,
}

impl Kept {
    /// Its layers' descriptors, as a report carries them: an overlay's lower and upper
    /// directories (Documentation/filesystems/overlayfs.rst, `lowerdir=`, `upperdir=`).
    fn fds(&self) -> [std::os::fd::RawFd; MAX_FDS] {
        [self.lower.as_raw_fd(), self.upper.as_raw_fd()]
    }
}

/// What a joiner's child built: its image's users, and its layers kept.
pub type Built = (Users, Kept);

/// The setup entry that makes an exec a joiner: `join=OFFSET,LEN`, its image's bytes on
/// the join disk, which the host gave it.
pub const ENTRY: &[u8] = b"join=";

/// The setup entry naming a joiner's writable layer from before on the join disk:
/// `join-layer=OFFSET,LEN`, an OCI layer as its last run left it (layer.rs), to put back
/// over its root before its command runs again.
pub const LAYER_ENTRY: &[u8] = b"join-layer=";

/// The range `setup`'s join entry names, if it has one; a malformed one is refused.
pub fn range(setup: &[Vec<u8>]) -> Option<Result<(u64, u64), String>> {
    entry_range(setup, ENTRY, "join")
}

/// The range `setup`'s join layer entry names, if it has one; a malformed one is refused.
pub fn layer_range(setup: &[Vec<u8>]) -> Option<Result<(u64, u64), String>> {
    entry_range(setup, LAYER_ENTRY, "join layer")
}

fn entry_range(setup: &[Vec<u8>], prefix: &[u8], what: &str) -> Option<Result<(u64, u64), String>> {
    let entry = setup.iter().find_map(|e| e.strip_prefix(prefix))?;
    let parsed = std::str::from_utf8(entry)
        .ok()
        .and_then(|e| e.split_once(','))
        .and_then(|(o, l)| Some((o.parse::<u64>().ok()?, l.parse::<u64>().ok()?)))
        .filter(|&(o, l)| l > 0 && o.checked_add(l).is_some());
    Some(parsed.ok_or_else(|| format!("a malformed {what} entry")))
}

/// The cgroup of the joiner init knows as exec `id`: beside the workload's, its own, as a
/// container's is.
pub fn cgroup(id: u32) -> String {
    format!("/sys/fs/cgroup{}", crate::run::joiner_path(id))
}

/// Each joiner's device filter, by its id: Docker's default program and its descriptor,
/// which the joiner's own devices take the place of (`devices::Prepared::attach_joiner`).
/// Init's alone, kept while its cgroup is.
static FILTERS: std::sync::Mutex<Vec<(u32, crate::devices::Filter)>> = std::sync::Mutex::new(Vec::new());

fn filters() -> std::sync::MutexGuard<'static, Vec<(u32, crate::devices::Filter)>> {
    FILTERS.lock().unwrap_or_else(std::sync::PoisonError::into_inner)
}

/// Makes joiner `id`'s cgroup, under Docker's device rules, as the workload's is.
pub fn make_cgroup(id: u32) -> Result<String, String> {
    let dir = cgroup(id);
    match std::fs::create_dir(&dir) {
        Err(e) if e.kind() != io::ErrorKind::AlreadyExists => return Err(format!("{dir}: {e}")),
        _ => {}
    }
    let filter = crate::devices::confine_joiner(&dir)?;
    filters().push((id, filter));
    Ok(dir)
}

/// Puts joiner `id`'s own devices, `devices`, on its cgroup in place of Docker's default
/// ones: their filter, or none where it is privileged.
pub fn attach_devices(id: u32, devices: &crate::devices::Prepared) -> Result<(), String> {
    let dir = cgroup(id);
    let filters = filters();
    let (_, default) = filters
        .iter()
        .find(|(j, _)| *j == id)
        .ok_or("a joiner's cgroup without its device filter")?;
    devices.attach_joiner(&dir, default)
}

/// Removes joiner `id`'s cgroup once its processes have gone: the kernel refuses while
/// any is left, and that cgroup is let be; its filter's descriptor goes with it.
pub fn remove_cgroup(id: u32) {
    if std::fs::remove_dir(cgroup(id)).is_ok() {
        filters().retain(|(j, _)| *j != id);
    }
}

/// Kills what is left in joiner `id`'s cgroup as its command ends: in a PID namespace of
/// another's, whose end is not its command's (pid_namespaces(7)), what it started goes on,
/// and runc kills what a container sharing one leaves (libcontainer, signalAllProcesses).
/// Looked at again until none is left, as one may have forked meanwhile; in a namespace of
/// its own, the kernel has killed them all.
pub fn kill_rest(id: u32) {
    let procs = format!("{}/cgroup.procs", cgroup(id));
    // A process forks at most once between looks; each look kills what it finds.
    for _ in 0..64 {
        let Ok(listed) = std::fs::read_to_string(&procs) else {
            return;
        };
        let mut found = 0;
        for pid in listed
            .lines()
            .filter_map(|l| l.trim().parse::<libc::pid_t>().ok())
        {
            // SAFETY: kill(2) of a process of the joiner's cgroup, by its PID in init's
            // namespace, as cgroup.procs lists it to init.
            if unsafe { libc::kill(pid, libc::SIGKILL) } == 0 {
                found += 1;
            }
        }
        if found == 0 {
            return;
        }
    }
}

// include/uapi/linux/loop.h and include/uapi/linux/major.h.
pub(crate) const LOOP_SET_FD: libc::c_ulong = 0x4C00;
pub(crate) const LOOP_SET_STATUS64: libc::c_ulong = 0x4C04;
pub(crate) const LOOP_SET_DIRECT_IO: libc::c_ulong = 0x4C08;
pub(crate) const LOOP_CTL_GET_FREE: libc::c_ulong = 0x4C82;
pub(crate) const LO_FLAGS_READ_ONLY: u32 = 1;
pub(crate) const LO_FLAGS_AUTOCLEAR: u32 = 4;
const LOOP_MAJOR: u32 = 7;
const MISC_MAJOR: u32 = 10;
const LOOP_CTRL_MINOR: u32 = 237;

#[repr(C)]
pub(crate) struct LoopInfo64 {
    pub(crate) lo_device: u64,
    pub(crate) lo_inode: u64,
    pub(crate) lo_rdevice: u64,
    pub(crate) lo_offset: u64,
    pub(crate) lo_sizelimit: u64,
    pub(crate) lo_number: u32,
    pub(crate) lo_encrypt_type: u32,
    pub(crate) lo_encrypt_key_size: u32,
    pub(crate) lo_flags: u32,
    pub(crate) lo_file_name: [u8; 64],
    pub(crate) lo_crypt_name: [u8; 64],
    pub(crate) lo_encrypt_key: [u8; 32],
    pub(crate) lo_init: [u64; 2],
}

/// How long the join disk may take to show its new capacity: the guest's driver reads it
/// on the config-change interrupt, on a workqueue (drivers/block/virtio_blk.c,
/// virtblk_config_changed_work), which the host raised before it gave the joiner's range.
const CAPACITY_WAIT: Duration = Duration::from_secs(5);

/// Where a joiner's child keeps what only it sees as it builds its root: a tmpfs over
/// `/dev` in its own mount namespace.
const SCRATCH: &str = "/dev";

/// The joiner's root, its image's lower layer and its writable one, under [`SCRATCH`].
const ROOT: &str = "/dev/join/root";
const LOWER: &str = "/dev/join/lower";
const RW: &str = "/dev/join/rw";

fn c(s: &str) -> Result<CString, String> {
    CString::new(s).map_err(|_| format!("{s:?} contains NUL"))
}

fn last(what: &str) -> String {
    format!("{what}: {}", io::Error::last_os_error())
}

fn mount(source: &str, target: &str, fstype: &str, flags: libc::c_ulong, data: &str) -> Result<(), String> {
    let (s, t, f, d) = (c(source)?, c(target)?, c(fstype)?, c(data)?);
    // SAFETY: NUL-terminated strings that outlive the call.
    if unsafe { libc::mount(s.as_ptr(), t.as_ptr(), f.as_ptr(), flags, d.as_ptr().cast()) } != 0 {
        return Err(last(&format!("mounting {fstype} on {target}")));
    }
    Ok(())
}

fn mkdir(path: &str) -> Result<(), String> {
    match std::fs::create_dir_all(path) {
        Ok(()) => Ok(()),
        Err(e) => Err(format!("mkdir {path}: {e}")),
    }
}

fn mknod(path: &str, kind: libc::mode_t, major: u32, minor: u32) -> Result<(), String> {
    let p = c(path)?;
    // SAFETY: a NUL-terminated path.
    if unsafe { libc::mknod(p.as_ptr(), kind | 0o600, libc::makedev(major, minor)) } != 0 {
        return Err(last(&format!("mknod {path}")));
    }
    Ok(())
}

/// The setns(2) of `pid`'s namespace `ns` (`/proc/<pid>/ns/<ns>`), as `kind`.
fn enter(pid: libc::pid_t, ns: &str, kind: libc::c_int) -> Result<(), String> {
    let file = File::open(format!("/proc/{pid}/ns/{ns}"))
        .map_err(|e| format!("the workload's {ns} namespace: {e}"))?;
    setns(&file, kind, ns)
}

fn setns(file: &File, kind: libc::c_int, ns: &str) -> Result<(), String> {
    // SAFETY: setns(2) on a descriptor this process holds.
    if unsafe { libc::setns(file.as_raw_fd(), kind) } != 0 {
        return Err(last(&format!("joining the {ns} namespace")));
    }
    Ok(())
}

/// A copy of the mount at `path` in the mount namespace of `from`'s process, or in this
/// process's own, detached from either (open_tree(2), `OPEN_TREE_CLONE`), for
/// [`attach`] to put in this one: a mount of another namespace no bind reaches
/// (fs/namespace.c, `may_copy_tree`), but its copy, an anonymous namespace's root, moves
/// into any (`do_move_mount`).
fn clone_tree(from: Option<libc::pid_t>, path: &str) -> Result<OwnedFd, String> {
    let back = match from {
        Some(pid) => {
            let own = File::open("/proc/self/ns/mnt").map_err(|e| format!("its mount namespace: {e}"))?;
            enter(pid, "mnt", libc::CLONE_NEWNS)?;
            Some(own)
        }
        None => None,
    };
    let p = c(path)?;
    // SAFETY: open_tree(2) of a NUL-terminated path, which returns a descriptor or -1.
    let fd = unsafe {
        libc::syscall(
            libc::SYS_open_tree,
            libc::AT_FDCWD,
            p.as_ptr(),
            libc::OPEN_TREE_CLONE | libc::OPEN_TREE_CLOEXEC,
        )
    };
    let cloned = (fd >= 0)
        .then(|| {
            // SAFETY: a fresh descriptor nothing else owns.
            unsafe { OwnedFd::from_raw_fd(fd as libc::c_int) }
        })
        .ok_or_else(|| last(&format!("copying the mount at {path}")));
    // Back in its own namespace before anything else, whatever the copy did.
    if let Some(own) = back {
        setns(&own, libc::CLONE_NEWNS, "its own mount")?;
    }
    cloned
}

/// The joiner's own `/etc/FILE`, holding `bytes`, in its root ([`ROOT`]) before it moves
/// there: a file of its writable layer's, never a link it could have put there.
fn own_file(file: &str, bytes: &[u8]) -> Result<(), String> {
    let target = format!("{ROOT}/etc/{file}");
    if let Ok(m) = std::fs::symlink_metadata(&target)
        && !m.is_file()
    {
        let _ = std::fs::remove_dir_all(&target).or_else(|_| std::fs::remove_file(&target));
    }
    std::fs::write(&target, bytes).map_err(|e| format!("{target}: {e}"))
}

/// A copy of what `bind.source` names in the mount namespace of `workload`'s process, its
/// mounts under it with it, detached (open_tree(2), `OPEN_TREE_CLONE | AT_RECURSIVE`, as
/// dockerd's binds are recursive), read-only with its mounts unless `bind.writable`
/// (mount_setattr(2), `AT_RECURSIVE`); made there first where it is missing and asked to
/// be. Its path is resolved from that namespace's root, the workload's files, past none of
/// them: `..` stops at it, and so does a link, absolute or not.
fn own_tree(workload: libc::pid_t, bind: &OwnBind) -> Result<OwnedFd, String> {
    let own = File::open("/proc/self/ns/mnt").map_err(|e| format!("its mount namespace: {e}"))?;
    enter(workload, "mnt", libc::CLONE_NEWNS)?;
    let cloned = (|| {
        if bind.create && std::fs::symlink_metadata(&bind.source).is_err() {
            use std::os::unix::fs::DirBuilderExt as _;
            std::fs::DirBuilder::new()
                .recursive(true)
                .mode(0o755)
                .create(&bind.source)
                .map_err(|e| format!("making {} in its microVM's files: {e}", bind.source))?;
        }
        let p = c(&bind.source)?;
        // SAFETY: open_tree(2) of a NUL-terminated path, which returns a descriptor or -1.
        let fd = unsafe {
            libc::syscall(
                libc::SYS_open_tree,
                libc::AT_FDCWD,
                p.as_ptr(),
                libc::OPEN_TREE_CLONE | libc::OPEN_TREE_CLOEXEC | libc::AT_RECURSIVE as libc::c_uint,
            )
        };
        if fd < 0 {
            return Err(last(&format!("copying {} of its microVM's files", bind.source)));
        }
        // SAFETY: a fresh descriptor nothing else owns.
        Ok(unsafe { OwnedFd::from_raw_fd(fd as libc::c_int) })
    })();
    // Back in its own namespace before anything else, whatever the copy did.
    setns(&own, libc::CLONE_NEWNS, "its own mount")?;
    let tree = cloned?;
    if !bind.writable {
        let attr = libc::mount_attr {
            attr_set: libc::MOUNT_ATTR_RDONLY,
            attr_clr: 0,
            propagation: 0,
            userns_fd: 0,
        };
        let empty = c("")?;
        // SAFETY: mount_setattr(2) of our own descriptor, with an attribute of its size.
        let rc = unsafe {
            libc::syscall(
                libc::SYS_mount_setattr,
                tree.as_raw_fd(),
                empty.as_ptr(),
                libc::AT_EMPTY_PATH | libc::AT_RECURSIVE,
                &raw const attr,
                std::mem::size_of::<libc::mount_attr>(),
            )
        };
        if rc != 0 {
            return Err(last(&format!("making {} read-only", bind.source)));
        }
    }
    Ok(tree)
}

/// Puts `tree`, from [`own_tree`], at `target` in the root this process has: a directory
/// made there for a directory's, a file for a file's, each made in this root alone.
fn put_own(tree: &OwnedFd, target: &str) -> Result<(), String> {
    // SAFETY: an all-zero stat is a valid out-parameter.
    let mut st: libc::stat = unsafe { std::mem::zeroed() };
    // SAFETY: fstat(2) of our own descriptor into a stat of ours.
    if unsafe { libc::fstat(tree.as_raw_fd(), &raw mut st) } != 0 {
        return Err(last(&format!("what goes at {target}")));
    }
    let made = if st.st_mode & libc::S_IFMT == libc::S_IFDIR {
        use std::os::unix::fs::DirBuilderExt as _;
        std::fs::DirBuilder::new()
            .recursive(true)
            .mode(0o755)
            .create(target)
    } else {
        let parent = std::path::Path::new(target)
            .parent()
            .unwrap_or(std::path::Path::new("/"));
        std::fs::create_dir_all(parent).and_then(|()| {
            std::fs::OpenOptions::new()
                .write(true)
                .create(true)
                .truncate(false)
                .open(target)
                .map(drop)
        })
    };
    made.map_err(|e| format!("{target}: {e}"))?;
    attach(tree, target)
}

/// Puts `tree`, from [`clone_tree`], at `path` in this process's mount namespace.
fn attach(tree: &OwnedFd, path: &str) -> Result<(), String> {
    let (empty, p) = (c("")?, c(path)?);
    // SAFETY: move_mount(2) of our own descriptor to a NUL-terminated path.
    let rc = unsafe {
        libc::syscall(
            libc::SYS_move_mount,
            tree.as_raw_fd(),
            empty.as_ptr(),
            libc::AT_FDCWD,
            p.as_ptr(),
            libc::MOVE_MOUNT_F_EMPTY_PATH,
        )
    };
    if rc != 0 {
        return Err(last(&format!("putting the shared mount at {path}")));
    }
    Ok(())
}

/// Detaches the mount at `path`.
fn detach(path: &str) -> Result<(), String> {
    let p = c(path)?;
    // SAFETY: umount2(2) of a NUL-terminated path.
    if unsafe { libc::umount2(p.as_ptr(), libc::MNT_DETACH) } != 0 {
        return Err(last(&format!("unmounting {path}")));
    }
    Ok(())
}

/// The join disk's name under /sys/block, found by its serial, and its device number.
pub(crate) fn join_disk() -> Result<(String, u32, u32), String> {
    let serial = shards_abi::JOIN_DISK_SERIAL.as_bytes();
    for entry in std::fs::read_dir("/sys/block").map_err(|e| format!("/sys/block: {e}"))? {
        let Ok(entry) = entry else { continue };
        let name = entry.file_name().to_string_lossy().into_owned();
        if !name.starts_with("vd") {
            continue;
        }
        let said = std::fs::read(format!("/sys/block/{name}/serial")).unwrap_or_default();
        if said.trim_ascii_end() != serial {
            continue;
        }
        let dev =
            std::fs::read_to_string(format!("/sys/block/{name}/dev")).map_err(|e| format!("{name}: {e}"))?;
        let (major, minor) = dev
            .trim()
            .split_once(':')
            .and_then(|(a, b)| Some((a.parse().ok()?, b.parse().ok()?)))
            .ok_or_else(|| format!("{name}: a device number {dev:?}"))?;
        return Ok((name, major, minor));
    }
    Err("this microVM has no join disk".into())
}

/// Waits until the join disk `name` holds `end` bytes: its capacity, as the driver read
/// it, past the joiner's range.
pub(crate) fn await_capacity(name: &str, end: u64) -> Result<(), String> {
    let deadline = Instant::now() + CAPACITY_WAIT;
    loop {
        let sectors: u64 = std::fs::read_to_string(format!("/sys/block/{name}/size"))
            .map_err(|e| format!("{name}'s size: {e}"))?
            .trim()
            .parse()
            .map_err(|_| format!("{name}'s size is no number"))?;
        if sectors.saturating_mul(512) >= end {
            return Ok(());
        }
        if Instant::now() >= deadline {
            return Err(format!(
                "the join disk holds {} bytes, not the {end} its image needs, after {CAPACITY_WAIT:?}",
                sectors.saturating_mul(512)
            ));
        }
        std::thread::sleep(Duration::from_millis(1));
    }
}

/// A loop device over `len` bytes of the disk at `disk` from `offset`, read-only and let go
/// with its last user (`LO_FLAGS_AUTOCLEAR`): the joiner's root, which ends with its mount
/// namespace. Its node made at `/dev/join/loop`, and returned open: the device lets go of
/// its disk at its last close, so it is held until its mount holds it. With LOOP_SET_FD and
/// LOOP_SET_STATUS64, which every kernel has, rather than LOOP_CONFIGURE (Linux 5.8).
fn loop_device(disk: &str, offset: u64, len: u64) -> Result<(String, File), String> {
    mknod(
        "/dev/join/loop-control",
        libc::S_IFCHR,
        MISC_MAJOR,
        LOOP_CTRL_MINOR,
    )?;
    let control = File::open("/dev/join/loop-control").map_err(|e| format!("loop-control: {e}"))?;
    let backing = File::open(disk).map_err(|e| format!("the join disk: {e}"))?;
    // Another joiner starting may take the free device first: try again.
    for _ in 0..64 {
        // SAFETY: ioctl(2) on loop-control, which takes no argument.
        let n = unsafe { libc::ioctl(control.as_raw_fd(), LOOP_CTL_GET_FREE as _) };
        if n < 0 {
            return Err(last("a free loop device"));
        }
        let n = u32::try_from(n).map_err(|_| "a loop device number out of range")?;
        let path = format!("/dev/join/loop{n}");
        let _ = std::fs::remove_file(&path);
        mknod(&path, libc::S_IFBLK, LOOP_MAJOR, n)?;
        let dev = std::fs::OpenOptions::new()
            .read(true)
            .open(&path)
            .map_err(|e| format!("{path}: {e}"))?;
        // SAFETY: ioctl(2) on the loop device with the backing file's descriptor.
        if unsafe { libc::ioctl(dev.as_raw_fd(), LOOP_SET_FD as _, backing.as_raw_fd()) } != 0 {
            if io::Error::last_os_error().raw_os_error() == Some(libc::EBUSY) {
                continue;
            }
            return Err(last("attaching the join disk to a loop device"));
        }
        let info = LoopInfo64 {
            lo_device: 0,
            lo_inode: 0,
            lo_rdevice: 0,
            lo_offset: offset,
            lo_sizelimit: len,
            lo_number: 0,
            lo_encrypt_type: 0,
            lo_encrypt_key_size: 0,
            lo_flags: LO_FLAGS_READ_ONLY | LO_FLAGS_AUTOCLEAR,
            lo_file_name: [0; 64],
            lo_crypt_name: [0; 64],
            lo_encrypt_key: [0; 32],
            lo_init: [0; 2],
        };
        // SAFETY: ioctl(2) reading `info`, which outlives it.
        if unsafe { libc::ioctl(dev.as_raw_fd(), LOOP_SET_STATUS64 as _, &raw const info) } != 0 {
            return Err(last("setting the joiner's range on its loop device"));
        }
        direct_io(&dev).map_err(|e| format!("reading the joiner's range past the join disk's cache: {e}"))?;
        return Ok((path, dev));
    }
    Err("no loop device stayed free".into())
}

/// Has the loop device `dev` read its range straight from its disk (LOOP_SET_DIRECT_IO,
/// Linux 4.4), not through the disk's page cache as well as its file system's: a held
/// build's reread of a 512 MiB file through a cache layer's loop filled its builder's memory
/// with the join disk's copy at the read's pace (Buffers, in no cgroup the build is held
/// in), its host throttling it past its budget for 15 minutes (D188, CI's ubuntu-24.04,
/// 2026-10-27). Every range starts on a mebibyte (virtio block.rs `RANGE_ALIGN`), which any
/// block size divides, so the kernel's alignment checks (loop_update_dio) always pass.
pub(crate) fn direct_io(dev: &File) -> io::Result<()> {
    let on: libc::c_ulong = 1;
    // SAFETY: ioctl(2) on a loop device, with an integer argument.
    if unsafe { libc::ioctl(dev.as_raw_fd(), LOOP_SET_DIRECT_IO as _, on) } != 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

/// Builds joiner `join`'s root and namespaces in this process, a standby init forked in the
/// PID namespace its `pid` says (PID 1 of one of its own, as a container's command is), in
/// init's cgroup: a mount namespace of its own, private;
/// the workload's hostname in a UTS namespace of its own; the workload's network namespace;
/// an IPC namespace of its own; its image's range of the join disk on a loop device, under
/// a tmpfs overlay, its root; the workload's `/etc/hostname`, `/etc/hosts` and
/// `/etc/resolv.conf` over its own; then its cgroup, `cgroup`, and a cgroup namespace
/// rooted there; then the mounts Docker gives a container. Its writable layer from before,
/// if it has one, is put back over its root first. Returns its user database,
/// `/etc/passwd` and `/etc/group`, which init resolves its user against.
pub fn build(join: Join, cgroup: &str) -> Result<Built, String> {
    let end = [Some((join.offset, join.len)), join.layer]
        .into_iter()
        .flatten()
        .try_fold(0u64, |end, (offset, len)| Some(end.max(offset.checked_add(len)?)))
        .ok_or("a join range past the end")?;
    // SAFETY: unshare(2) and mount(2) of NUL-terminated literals, in a single-threaded
    // fork of init's.
    unsafe {
        if libc::unshare(libc::CLONE_NEWNS) != 0 {
            return Err(last("a mount namespace of its own"));
        }
        if libc::mount(
            std::ptr::null(),
            c"/".as_ptr(),
            std::ptr::null(),
            libc::MS_REC | libc::MS_PRIVATE,
            std::ptr::null(),
        ) != 0
        {
            return Err(last("its mounts made private"));
        }
    }
    // The workload's hostname, in a namespace of its own unless it shares the microVM's
    // (`--uts host`, D156).
    enter(join.net_of.unwrap_or(join.workload), "uts", libc::CLONE_NEWUTS)?;
    // Its network: the workload's; the namespace init made it on the microVM's switch,
    // as a member its engine made (D181); or its loopback alone.
    match (&join.member, join.net_of) {
        (Some(m), _) => {
            // SAFETY: setns(2) of this single-threaded child into a namespace init holds.
            if unsafe { libc::setns(m.ns, libc::CLONE_NEWNET) } != 0 {
                return Err(last("its network namespace on the microVM's switch"));
            }
        }
        (None, Some(other)) => enter(other, "net", libc::CLONE_NEWNET)?,
        (None, None) if join.own_net_none => crate::members::alone()?,
        (None, None) => enter(join.workload, "net", libc::CLONE_NEWNET)?,
    }
    // Its IPC namespace (D156): its own, the microVM's, or another run's of this microVM,
    // with the /dev/shm that goes with a shared one, copied while the mount it copies is
    // in reach, before /dev is its scratch, and put in its root once that has its own /dev.
    let shm = match join.ipc {
        Ipc::Own | Ipc::None => None,
        Ipc::Host => {
            crate::setup::enter_microvm(libc::CLONE_NEWIPC)
                .map_err(|e| format!("the microVM's IPC namespace: {}", io::Error::from_raw_os_error(e)))?;
            Some(clone_tree(None, "/dev/shm")?)
        }
        Ipc::Workload => {
            enter(join.workload, "ipc", libc::CLONE_NEWIPC)?;
            Some(clone_tree(Some(join.workload), "/dev/shm")?)
        }
        Ipc::Joiner(pid) => {
            enter(pid, "ipc", libc::CLONE_NEWIPC)?;
            Some(clone_tree(Some(pid), "/dev/shm")?)
        }
    };
    // Its binds of its microVM's own files (D181), copied while the workload's mount
    // namespace is in reach, and put in its root once that is its own.
    let mut owns = join
        .own_binds
        .iter()
        .map(|b| own_tree(join.workload, b).map(|tree| (tree, b.target.clone())))
        .collect::<Result<Vec<_>, String>>()?;
    // In another's network namespace, that one's names, the same files read-only, copied
    // from its mount namespace as a bind of the workload's files is, so that a link it put
    // there resolves in its files alone.
    if let Some(other) = join.net_of {
        for file in ["hostname", "hosts", "resolv.conf"] {
            let path = format!("/etc/{file}");
            let bind = OwnBind {
                source: path.clone(),
                target: path,
                writable: false,
                create: false,
            };
            owns.push((own_tree(other, &bind)?, bind.target));
        }
    }
    let own = if join.uts_host || join.net_of.is_some() {
        0
    } else {
        libc::CLONE_NEWUTS
    } | if shm.is_some() { 0 } else { libc::CLONE_NEWIPC };
    // SAFETY: unshare(2), in a single-threaded fork of init's.
    if own != 0 && unsafe { libc::unshare(own) } != 0 {
        return Err(last("its UTS and IPC namespaces"));
    }
    // A joiner with a network of its own has its own name.
    let own_net = join.member.is_some() || join.own_net_none;
    if own_net && !join.uts_host && !join.hostname.is_empty() {
        // SAFETY: a buffer of the given length.
        if unsafe { libc::sethostname(join.hostname.as_ptr().cast(), join.hostname.len()) } != 0 {
            return Err(last("its hostname"));
        }
    }
    // What only it sees as it builds its root.
    mount("tmpfs", SCRATCH, "tmpfs", libc::MS_NOSUID, "mode=0700")?;
    mkdir("/dev/join")?;
    let (name, major, minor) = join_disk()?;
    await_capacity(&name, end)?;
    mknod("/dev/join/disk", libc::S_IFBLK, major, minor)?;
    // Held open until its mount holds it (`loop_device`).
    let (device, _held) = loop_device("/dev/join/disk", join.offset, join.len)?;
    for dir in [LOWER, RW, ROOT] {
        mkdir(dir)?;
    }
    mount(&device, LOWER, "erofs", libc::MS_RDONLY, "")?;
    // Its writable layer, the size it asks for (`--storage-opt size=`, D156), else as much
    // as the workload's tmpfs holds, all the memory the microVM may have (D148): sized by
    // the memory it has now, a microVM that plugs its memory as it needs it would hold half
    // of what it booted with.
    let rw = match (join.rw_size, crate::plug::tmpfs_now()) {
        (Some(size), _) => format!("mode=0755,size={size}"),
        (None, Some(full)) => format!("mode=0755,{full}"),
        (None, None) => "mode=0755".to_string(),
    };
    mount("tmpfs", RW, "tmpfs", 0, &rw)?;
    for dir in ["/dev/join/rw/upper", "/dev/join/rw/work"] {
        mkdir(dir)?;
    }
    mount(
        "overlay",
        ROOT,
        "overlay",
        0,
        &format!(
            "lowerdir=/dev/join/lower,upperdir=/dev/join/rw/upper,workdir=/dev/join/rw/work,volatile,{}",
            crate::run::XINO
        ),
    )?;
    // What it changed before, over its image's files, as a run's (D37): before its users
    // are read, which it may have changed, and before anything is mounted in its root.
    if let Some((offset, len)) = join.layer {
        put_back("/dev/join/disk", offset, len)?;
    }
    // Its users, read before anything is mounted over its /etc.
    let users = (
        std::fs::read(format!("{ROOT}/etc/passwd")).ok(),
        std::fs::read(format!("{ROOT}/etc/group")).ok(),
    );
    // Its layers, kept before its root moves over them.
    let open_path = |path: &str| -> Result<OwnedFd, String> {
        use std::os::unix::fs::OpenOptionsExt;
        std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_PATH | libc::O_DIRECTORY)
            .open(path)
            .map(OwnedFd::from)
            .map_err(|e| format!("{path}: {e}"))
    };
    let kept = Kept {
        lower: open_path(LOWER)?,
        upper: open_path("/dev/join/rw/upper")?,
    };
    // The workload's files over its own, the same files: what the workload's run writes in
    // them, it sees. One with a network of its own names itself in its own: a member its
    // engine made by its address on the switch, under its host name and its names there
    // (D181), asking the agents' resolver at the switch's end of its link (D59), or the
    // resolvers its client named, or none where it reaches nothing past the microVM.
    etc_dir()?;
    let resolv = match (&join.member, &join.resolv) {
        (Some(_), Some(given)) => Some(given.clone()),
        (Some(m), None) if m.dns => {
            Some(format!("nameserver {}\noptions ndots:0\n", crate::links::TRANSIT_SWITCH).into_bytes())
        }
        (Some(_), None) => Some(Vec::new()),
        (None, given) => given.clone(),
    };
    if own_net {
        let name = String::from_utf8_lossy(&join.hostname).into_owned();
        own_file("hostname", format!("{name}\n").as_bytes())?;
        let mut hosts = crate::netplan::HOSTS.to_vec();
        for line in &join.hosts {
            hosts.extend_from_slice(line);
            hosts.push(b'\n');
        }
        if let Some(m) = &join.member {
            for (addr, given) in &m.on {
                let mut names: Vec<&str> = vec![name.as_str()];
                for n in given {
                    if !names.contains(&n.as_str()) {
                        names.push(n);
                    }
                }
                hosts.extend_from_slice(format!("{addr}\t{}\n", names.join(" ")).as_bytes());
            }
        }
        own_file("hosts", &hosts)?;
        if let Some(resolv) = &resolv {
            own_file("resolv.conf", resolv)?;
        }
    }
    let shared: &[&str] = match (own_net, &resolv) {
        _ if join.net_of.is_some() => &[],
        (true, Some(_)) => &[],
        (true, None) => &["resolv.conf"],
        (false, _) => &["hostname", "hosts", "resolv.conf"],
    };
    for &file in shared {
        let target = format!("{ROOT}/etc/{file}");
        match std::fs::symlink_metadata(&target) {
            Ok(m) if m.is_file() => {}
            Ok(_) => {
                let _ = std::fs::remove_dir_all(&target).or_else(|_| std::fs::remove_file(&target));
                File::create(&target).map_err(|e| format!("{target}: {e}"))?;
            }
            Err(_) => {
                File::create(&target).map_err(|e| format!("{target}: {e}"))?;
            }
        }
        mount(&format!("/etc/{file}"), &target, "", libc::MS_BIND, "")?;
    }
    // Its cgroup, once nothing more is opened outside it: its device rules hold from here.
    std::fs::OpenOptions::new()
        .write(true)
        .open(format!("{cgroup}/cgroup.procs"))
        .and_then(|mut f| f.write_all(b"0"))
        .map_err(|e| format!("its cgroup: {e}"))?;
    // A cgroup namespace rooted there, unless it sees the microVM's (`--cgroupns host`).
    // SAFETY: unshare(2), in a single-threaded fork of init's.
    if !join.cgroupns_host && unsafe { libc::unshare(libc::CLONE_NEWCGROUP) } != 0 {
        return Err(last("its cgroup namespace"));
    }
    pivot()?;
    crate::run::container_mounts(crate::run::shm()).map_err(|f| f.message)?;
    // Its /dev/shm (D156): the one it shares in place of its own, or none.
    match (&shm, join.ipc) {
        (Some(tree), _) => {
            detach("/dev/shm")?;
            attach(tree, "/dev/shm")?;
        }
        (None, Ipc::None) => detach("/dev/shm")?,
        (None, _) => {}
    }
    for (tree, target) in &owns {
        put_own(tree, target)?;
    }
    // Its cgroup, read-only: its limits are its to read, never to change (D156).
    mount(
        "cgroup2",
        "/sys/fs/cgroup",
        "cgroup2",
        libc::MS_RDONLY | libc::MS_NOSUID | libc::MS_NOEXEC | libc::MS_NODEV,
        "",
    )?;
    let mtab = "/etc/mtab";
    let _ = std::fs::remove_file(mtab);
    std::os::unix::fs::symlink("/proc/mounts", mtab).map_err(|e| format!("{mtab}: {e}"))?;
    crate::run::masked().map_err(|f| f.message)?;
    Ok((users, kept))
}

/// Puts back the joiner's writable layer from before, `len` bytes of the join disk at
/// `disk` from `offset`, over its root ([`ROOT`]), as go-archive's ApplyLayer puts a
/// layer back (layer.rs, `apply`). Applied with [`ROOT`] as this process's root, so
/// that no path or link the layer holds resolves past it (chroot(2)); the root it had is
/// taken back after, from a descriptor of it held meanwhile. What it reads of the disk is
/// let go of from the page cache as it goes: read once, it is the joiner's files after.
fn put_back(disk: &str, offset: u64, len: u64) -> Result<(), String> {
    use std::os::unix::fs::OpenOptionsExt;
    let disk = File::open(disk).map_err(|e| format!("the join disk: {e}"))?;
    let own = std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_PATH | libc::O_DIRECTORY)
        .open("/")
        .map_err(|e| format!("its root: {e}"))?;
    let root = c(ROOT)?;
    // SAFETY: chroot(2) and chdir(2) of NUL-terminated paths, in a single-threaded fork
    // of init's.
    if unsafe { libc::chroot(root.as_ptr()) } != 0 || unsafe { libc::chdir(c"/".as_ptr()) } != 0 {
        return Err(last("entering its root to put back its files"));
    }
    let mut layer = DiskRange {
        disk: &disk,
        at: offset,
        left: len,
    };
    let applied = shards_archive::apply_layer(
        &mut layer,
        std::path::Path::new("/"),
        &shards_archive::UnpackOptions::default(),
    );
    // SAFETY: fchdir(2) to the root this process had, which it holds, then chroot(2) and
    // chdir(2) of literals.
    let back = unsafe {
        libc::fchdir(own.as_raw_fd()) == 0
            && libc::chroot(c".".as_ptr()) == 0
            && libc::chdir(c"/".as_ptr()) == 0
    };
    if !back {
        return Err(last("leaving its root after putting back its files"));
    }
    applied
        .map(drop)
        .map_err(|e| format!("putting back the container's files: {e}"))
}

/// `left` bytes of the join disk from `at`, read in order; each read let go of from the
/// page cache once read (posix_fadvise(2), POSIX_FADV_DONTNEED).
struct DiskRange<'a> {
    disk: &'a File,
    at: u64,
    left: u64,
}

impl io::Read for DiskRange<'_> {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        use std::os::unix::fs::FileExt;
        let want = usize::try_from(self.left).unwrap_or(usize::MAX).min(buf.len());
        let Some(to) = buf.get_mut(..want).filter(|b| !b.is_empty()) else {
            return Ok(0);
        };
        let n = self.disk.read_at(to, self.at)?;
        if n == 0 {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "the join disk ended before the layer",
            ));
        }
        let (start, read) = (self.at, n as u64);
        // SAFETY: posix_fadvise(2) on a descriptor this process holds; advice only.
        unsafe {
            libc::posix_fadvise(
                self.disk.as_raw_fd(),
                i64::try_from(start).unwrap_or(i64::MAX),
                i64::try_from(read).unwrap_or(0),
                libc::POSIX_FADV_DONTNEED,
            )
        };
        self.at = self.at.saturating_add(read);
        self.left = self.left.saturating_sub(read);
        Ok(n)
    }
}

/// Makes the joiner's `/etc` a directory over an image that has anything else there, so
/// that its hosts, hostname and resolv.conf have a place.
fn etc_dir() -> Result<(), String> {
    let etc = format!("{ROOT}/etc");
    match std::fs::symlink_metadata(&etc) {
        Ok(m) if m.is_dir() => Ok(()),
        Ok(_) => {
            std::fs::remove_file(&etc).map_err(|e| format!("replacing {etc}: {e}"))?;
            mkdir(&etc)
        }
        Err(_) => mkdir(&etc),
    }
}

/// Moves this process's root to the joiner's ([`ROOT`]), and lets the workload's go.
fn pivot() -> Result<(), String> {
    let old = format!("{ROOT}/.old-root");
    mkdir(&old)?;
    let (new, put) = (c(ROOT)?, c(&old)?);
    // SAFETY: pivot_root(2) of NUL-terminated paths, then chdir(2), umount2(2) and rmdir(2)
    // of literals, in a single-threaded fork of init's.
    unsafe {
        if libc::syscall(libc::SYS_pivot_root, new.as_ptr(), put.as_ptr()) != 0 {
            return Err(last("entering its root"));
        }
        if libc::chdir(c"/".as_ptr()) != 0 {
            return Err(last("entering its root"));
        }
        if libc::umount2(c"/.old-root".as_ptr(), libc::MNT_DETACH) != 0 {
            return Err(last("leaving the workload's root"));
        }
        libc::rmdir(c"/.old-root".as_ptr());
    }
    Ok(())
}

/// What a joiner's child says to init once its root is built: its image's user database
/// and its layers' descriptors, or why it has no root. Its length first: the child, forked
/// from init, holds init's own end of the channel until it execs, so the channel's end is
/// no end of the report. The descriptors come with its first byte (`SCM_RIGHTS`).
pub fn report(to: OwnedFd, built: &Result<Built, String>) {
    let mut body = Vec::new();
    match built {
        Ok(((passwd, group), _)) => {
            body.push(1);
            for file in [passwd, group] {
                match file {
                    Some(b) => {
                        body.push(1);
                        body.extend(u32::try_from(b.len()).unwrap_or(u32::MAX).to_be_bytes());
                        body.extend(b.get(..u32::MAX as usize).unwrap_or(b));
                    }
                    None => body.push(0),
                }
            }
        }
        Err(why) => {
            body.push(0);
            body.extend(why.as_bytes());
        }
    }
    let mut bytes = u32::try_from(body.len())
        .unwrap_or(u32::MAX)
        .to_be_bytes()
        .to_vec();
    bytes.extend(body);
    let fds = match built {
        Ok((_, kept)) => kept.fds().to_vec(),
        Err(_) => Vec::new(),
    };
    let _ = send_with(&to, &bytes, &fds);
}

/// Init's side of [`report`]: the joiner's user database and its layers, or why it has no
/// root.
pub fn reported(from: OwnedFd) -> Result<Built, String> {
    let (bytes, mut fds) = receive_with(&from).map_err(|e| format!("joining: {e}"))?;
    let (len, body) = bytes
        .split_first_chunk::<4>()
        .ok_or("joining: its process ended before its root was built")?;
    let body = body
        .get(..u32::from_be_bytes(*len) as usize)
        .ok_or("joining: a truncated report")?;
    let (&ok, mut rest) = body.split_first().ok_or("joining: an empty report")?;
    if ok == 0 {
        return Err(format!("joining: {}", String::from_utf8_lossy(rest)));
    }
    let mut take = || -> Result<Option<Vec<u8>>, String> {
        let (&has, after) = rest.split_first().ok_or("joining: a truncated report")?;
        if has == 0 {
            rest = after;
            return Ok(None);
        }
        let (len, after) = after
            .split_first_chunk::<4>()
            .ok_or("joining: a truncated report")?;
        let len = u32::from_be_bytes(*len) as usize;
        let (file, after) = after.split_at_checked(len).ok_or("joining: a truncated report")?;
        rest = after;
        Ok(Some(file.to_vec()))
    };
    let passwd = take()?;
    let group = take()?;
    let (upper, lower) = (fds.pop(), fds.pop());
    let (Some(lower), Some(upper), true) = (lower, upper, fds.is_empty()) else {
        return Err("joining: its layers did not come with its report".into());
    };
    Ok(((passwd, group), Kept { lower, upper }))
}

/// A channel for [`report`]: init's end to read, the child's to write.
pub fn report_channel() -> Result<(OwnedFd, OwnedFd), String> {
    let mut fds = [0; 2];
    // SAFETY: socketpair(2) filling a two-int array.
    if unsafe {
        libc::socketpair(
            libc::AF_UNIX,
            libc::SOCK_STREAM | libc::SOCK_CLOEXEC,
            0,
            fds.as_mut_ptr(),
        )
    } != 0
    {
        return Err(last("a channel for joining"));
    }
    let [r, w] = fds;
    // SAFETY: fresh descriptors nothing else owns.
    Ok(unsafe { (OwnedFd::from_raw_fd(r), OwnedFd::from_raw_fd(w)) })
}

/// The most descriptors a report carries: a joiner's layers, as many as [`Kept`] holds
/// descriptors, each of which [`Kept::fds`] returns (an array of this length, so that one
/// more or less fails to build).
const MAX_FDS: usize = std::mem::size_of::<Kept>() / std::mem::size_of::<OwnedFd>();

/// Sends `bytes` on `sock`, `fds` with their first byte (`SCM_RIGHTS`, unix(7)).
fn send_with(sock: &OwnedFd, bytes: &[u8], fds: &[std::os::fd::RawFd]) -> io::Result<()> {
    let mut sent = 0;
    while sent < bytes.len() {
        let rest = bytes.get(sent..).unwrap_or_default();
        let mut iov = libc::iovec {
            iov_base: rest.as_ptr().cast_mut().cast(),
            iov_len: rest.len(),
        };
        let mut control = [0u64; 8];
        // SAFETY: an all-zero msghdr, then filled with buffers of ours that outlive the call.
        let mut msg: libc::msghdr = unsafe { std::mem::zeroed() };
        msg.msg_iov = &raw mut iov;
        msg.msg_iovlen = 1;
        if sent == 0 && !fds.is_empty() && fds.len() <= MAX_FDS {
            let data = std::mem::size_of_val(fds);
            msg.msg_control = control.as_mut_ptr().cast();
            // SAFETY: CMSG_SPACE, CMSG_LEN and CMSG_FIRSTHDR of a control buffer large enough
            // for MAX_FDS descriptors, whose header and data are written in it.
            unsafe {
                msg.msg_controllen = libc::CMSG_SPACE(u32::try_from(data).unwrap_or(u32::MAX)) as _;
                let c = libc::CMSG_FIRSTHDR(&raw const msg);
                if c.is_null() {
                    return Err(io::Error::other("no room for the layers' descriptors"));
                }
                (*c).cmsg_level = libc::SOL_SOCKET;
                (*c).cmsg_type = libc::SCM_RIGHTS;
                (*c).cmsg_len = libc::CMSG_LEN(u32::try_from(data).unwrap_or(u32::MAX)) as _;
                std::ptr::copy_nonoverlapping(fds.as_ptr().cast::<u8>(), libc::CMSG_DATA(c), data);
            }
        }
        // SAFETY: sendmsg(2) of the message just built.
        let n = unsafe { libc::sendmsg(sock.as_raw_fd(), &raw const msg, libc::MSG_NOSIGNAL) };
        match usize::try_from(n) {
            Ok(0) => return Err(io::Error::from(io::ErrorKind::WriteZero)),
            Ok(n) => sent += n,
            Err(_) => {
                let e = io::Error::last_os_error();
                if e.kind() != io::ErrorKind::Interrupted {
                    return Err(e);
                }
            }
        }
    }
    Ok(())
}

/// Reads `sock` to its end: the bytes, and the descriptors that came with them.
fn receive_with(sock: &OwnedFd) -> io::Result<(Vec<u8>, Vec<OwnedFd>)> {
    let (mut bytes, mut fds) = (Vec::new(), Vec::new());
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let mut iov = libc::iovec {
            iov_base: buf.as_mut_ptr().cast(),
            iov_len: buf.len(),
        };
        let mut control = [0u64; 8];
        // SAFETY: as in `send_with`.
        let mut msg: libc::msghdr = unsafe { std::mem::zeroed() };
        msg.msg_iov = &raw mut iov;
        msg.msg_iovlen = 1;
        msg.msg_control = control.as_mut_ptr().cast();
        msg.msg_controllen = std::mem::size_of_val(&control) as _;
        // SAFETY: recvmsg(2) into the buffers just described, all of ours and alive; with
        // MSG_CMSG_CLOEXEC, what it brings is closed on exec.
        let n = unsafe { libc::recvmsg(sock.as_raw_fd(), &raw mut msg, libc::MSG_CMSG_CLOEXEC) };
        let n = match usize::try_from(n) {
            Ok(n) => n,
            Err(_) => {
                let e = io::Error::last_os_error();
                if e.kind() == io::ErrorKind::Interrupted {
                    continue;
                }
                return Err(e);
            }
        };
        // SAFETY: CMSG_FIRSTHDR and CMSG_NXTHDR walk the control buffer recvmsg filled; an
        // SCM_RIGHTS header's data is the descriptors it brought, now this process's.
        unsafe {
            let mut c = libc::CMSG_FIRSTHDR(&raw const msg);
            while !c.is_null() {
                if (*c).cmsg_level == libc::SOL_SOCKET && (*c).cmsg_type == libc::SCM_RIGHTS {
                    let len = ((*c).cmsg_len as usize).saturating_sub(libc::CMSG_LEN(0) as usize);
                    let count = len / std::mem::size_of::<std::os::fd::RawFd>();
                    let data = libc::CMSG_DATA(c).cast::<std::os::fd::RawFd>();
                    for i in 0..count {
                        let fd = std::ptr::read_unaligned(data.add(i));
                        fds.push(OwnedFd::from_raw_fd(fd));
                    }
                }
                c = libc::CMSG_NXTHDR(&raw const msg, c);
            }
        }
        if n == 0 {
            return Ok((bytes, fds));
        }
        bytes.extend_from_slice(buf.get(..n).unwrap_or_default());
        // The whole report, by its length: init's copy of the child's end may stay open.
        if let Some((len, body)) = bytes.split_first_chunk::<4>()
            && body.len() >= u32::from_be_bytes(*len) as usize
        {
            return Ok((bytes, fds));
        }
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    #[test]
    fn a_join_entry_names_its_range() {
        let setup = |e: &str| vec![b"caps=1".to_vec(), e.as_bytes().to_vec()];
        assert_eq!(range(&setup("join=1048576,4096")), Some(Ok((1 << 20, 4096))));
        assert_eq!(range(&[b"caps=1".to_vec()]), None);
        // Its layer from before, its own entry, which the image's is not.
        let both = [b"join=0,512".to_vec(), b"join-layer=2097152,1024".to_vec()];
        assert_eq!(range(&both), Some(Ok((0, 512))));
        assert_eq!(layer_range(&both), Some(Ok((2 << 20, 1024))));
        assert_eq!(layer_range(&setup("join=1048576,4096")), None);
        for bad in [
            "join=",
            "join=1",
            "join=a,b",
            "join=1,0",
            "join=18446744073709551615,2",
        ] {
            assert!(range(&setup(bad)).unwrap().is_err(), "{bad}");
            let layer = bad.replacen("join=", "join-layer=", 1);
            assert!(layer_range(&setup(&layer)).unwrap().is_err(), "{layer}");
        }
    }

    #[test]
    fn a_report_says_the_users_and_layers_or_why() {
        let dir = |name: &str| {
            use std::os::unix::fs::OpenOptionsExt;
            let path = shards_testdir::TempDir::new(&format!("join-{name}")).unwrap();
            let fd: OwnedFd = std::fs::OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_PATH | libc::O_DIRECTORY)
                .open(&path)
                .unwrap()
                .into();
            (path, fd)
        };
        for users in [
            (Some(b"root:x:0:0::/root:/bin/sh\n".to_vec()), None),
            (None, Some(b"root:x:0:\n".to_vec())),
            (None, None),
        ] {
            let ((lower_path, lower), (upper_path, upper)) = (dir("lower"), dir("upper"));
            let (r, w) = report_channel().unwrap();
            report(w, &Ok((users.clone(), Kept { lower, upper })));
            let (back, kept) = reported(r).unwrap();
            assert_eq!(back, users);
            // The descriptors that came name the directories sent.
            let named =
                |fd: &OwnedFd| std::fs::read_link(format!("/proc/self/fd/{}", fd.as_raw_fd())).unwrap();
            assert_eq!(
                (named(&kept.lower), named(&kept.upper)),
                (lower_path.to_path_buf(), upper_path.to_path_buf())
            );
        }
        let (r, w) = report_channel().unwrap();
        let why = "mounting erofs on /dev/join/lower: Invalid argument".to_string();
        report(w, &Err(why.clone()));
        assert_eq!(reported(r).unwrap_err(), format!("joining: {why}"));
    }
}

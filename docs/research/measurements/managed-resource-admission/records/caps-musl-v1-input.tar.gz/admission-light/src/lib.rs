// Isolated module import only; full init caller is a separate root gate.
#[allow(dead_code)]
#[path = "../../crates/init/src/domains/admission.rs"]
mod admission;

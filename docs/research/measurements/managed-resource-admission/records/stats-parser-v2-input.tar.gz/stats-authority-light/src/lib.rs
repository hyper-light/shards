#[cfg(test)]
mod legacy_usage {
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(super) struct Usage {
    pub cpu: u64,
    pub system: u64,
    pub online: u64,
    pub memory: u64,
    pub inactive_file: u64,
    pub limit: u64,
    pub pids: u64,
    pub read: u64,
    pub write: u64,
    pub rx: u64,
    pub tx: u64,
}

impl Usage {
    fn parse(text: &str) -> Usage {
        let mut u = Usage::default();
        for line in text.lines() {
            let Some((k, v)) = line.split_once(' ') else {
                continue;
            };
            let v: u64 = v.trim().parse().unwrap_or(0);
            match k {
                "cpu" => u.cpu = v,
                "system" => u.system = v,
                "online" => u.online = v,
                "memory" => u.memory = v,
                "inactive_file" => u.inactive_file = v,
                "limit" => u.limit = v,
                "pids" => u.pids = v,
                "read" => u.read = v,
                "write" => u.write = v,
                "rx" => u.rx = v,
                "tx" => u.tx = v,
                _ => {}
            }
        }
        u
    }

}
mod tests;
}

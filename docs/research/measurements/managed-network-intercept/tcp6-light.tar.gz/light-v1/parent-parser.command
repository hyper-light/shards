cargo test -p shards-testguest --bin shards-testguest --target x86_64-unknown-linux-gnu -j4 managed_network::tests::interception_commands_keep_explicit_ip_families -- --exact --nocapture 

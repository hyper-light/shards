cargo +1.98.1 clippy --offline --manifest-path /home/adalundhe/managed-network-udp-light-v3/Cargo.toml --tests --target x86_64-unknown-linux-gnu -j4 -- -D warnings 

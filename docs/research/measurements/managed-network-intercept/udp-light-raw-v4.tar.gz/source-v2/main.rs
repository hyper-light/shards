#![cfg_attr(test, allow(clippy::panic, clippy::unwrap_used, clippy::expect_used, clippy::indexing_slicing))]
#[path = "crates/testguest/src/main-wrapper.rs"]
mod native;
fn main() { std::process::exit(native::managed_network::main()); }

#![cfg_attr(test, allow(clippy::panic, clippy::unwrap_used, clippy::expect_used, clippy::indexing_slicing))]
#[path = "crates/testguest/src/managed_network.rs"]
mod managed_network;
fn main() { std::process::exit(managed_network::main()); }

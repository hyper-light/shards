cargo clippy -p shards-testguest --bin shards-testguest --tests --target x86_64-unknown-linux-gnu -j4 -- -D warnings 

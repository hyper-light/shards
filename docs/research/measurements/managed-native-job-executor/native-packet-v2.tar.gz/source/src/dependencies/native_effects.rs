#[path="native_effects/file.rs"] pub(crate) mod file;
#[path="native_effects/objects.rs"] pub(crate) mod objects;
#[path="native_effects/literals.rs"] pub(crate) mod literals;
#[path="native_effects/process.rs"] pub(crate) mod process;

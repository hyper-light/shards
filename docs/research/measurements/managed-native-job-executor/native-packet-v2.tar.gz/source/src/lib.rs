extern crate self as shards_ipc;
#[path = "dependencies/ipc/child_fds.rs"]
pub mod child_fds;
mod server {
pub(super) const RESOLVE_NO_XDEV: u64 = 0x01;
pub(super) const RESOLVE_NO_MAGICLINKS: u64 = 0x02;
pub(super) const RESOLVE_NO_SYMLINKS: u64 = 0x04;
pub(super) const RESOLVE_BENEATH: u64 = 0x08;
}
#[path = "dependencies/native_effects.rs"]
mod native_effects;

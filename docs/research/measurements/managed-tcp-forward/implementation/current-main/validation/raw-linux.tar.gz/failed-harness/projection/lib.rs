#![allow(dead_code)]
#[path = "../source/crates/testguest/src/managed_network.rs"]
mod managed_network;

["cargo", "+1.98.1", "clippy", "--offline", "--manifest-path", "/home/adalundhe/managed-network-udp-local-host-light-v1/Cargo.toml", "-j4", "--tests", "--", "-D", "warnings"]

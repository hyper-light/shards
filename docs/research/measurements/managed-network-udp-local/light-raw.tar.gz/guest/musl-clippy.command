cargo +1.98.1 clippy --offline --manifest-path /home/adalundhe/managed-network-udp-local-light-v1/Cargo.toml --tests --target x86_64-unknown-linux-musl -j4 -- -D warnings 
